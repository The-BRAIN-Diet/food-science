---
id: mackerel
title: Mackerel
sidebar_label: Mackerel
description: Oily fish rich in EPA/DHA, CoQ10, taurine, and vitamin D
tags:
  - Food
  - Mackerel
  - Omega-3 Fatty Acids
  - EPA
  - DHA
  - CoQ10
  - Taurine
  - Vitamin D
list_image: /img/foods/mackerel/mackerel_thumb.webp
nutrition_per_100g:
  vitamin_k_ug: 5
  vitamin_d_ug: 16.1
  vitamin_a_rae_ug: 50
  vitamin_e_mg: 1.52
  choline_mg: 65
  fat_g: 13.89
  kcal: 205
  linoleic_g: 0.219
  calcium_mg: 12
  potassium_mg: 314
  zinc_mg: 0.63
  vitamin_b3_mg: 9.08
  vitamin_b5_mg: 0.856
  vitamin_b6_mg: 0.399
  protein_g: 18.6
  iron_mg: 1.63
  magnesium_mg: 76
  phosphorus_mg: 217
  sodium_mg: 90
  copper_mg: 0.073
  manganese_mg: 0.015
  sat_fat_g: 3.257
  vitamin_c_mg: 0.4
  vitamin_b1_mg: 0.176
  vitamin_b2_mg: 0.312
  folate_ug: 1
  vitamin_b12_ug: 8.71
  dha_mg: 1401
  epa_mg: 898
  selenium_ug: 44.1
  omega3_mg: 2511
  pufa_18_3_unresolved_mg: 159
omega3_components:
  - nutrient: dha_mg
    identity: 22:6 n-3 (DHA)
    amount_mg: 1401
  - nutrient: epa_mg
    identity: 20:5 n-3 (EPA)
    amount_mg: 898
  - nutrient: dpa_mg
    identity: 22:5 n-3 (DPA)
    amount_mg: 212
nutrition_source:
  database: USDA FoodData Central
  food_name: Fish, mackerel, Atlantic, raw
  fdc_id: 175119
  retrieval_method: SR Legacy bulk (April 2018)
  basis: per 100 g edible portion
  last_checked: '2026-08-15'
protein_profile_note: Complete essential amino acid profile.
main_image: /img/foods/mackerel/mackerel_medium.webp
legacy_list_image: /img/foods/mackerel/mackerel_thumb.webp
legacy_main_image: /img/foods/mackerel/mackerel_medium.webp
nutrition_supplementary_sources:
  - key: coq10_qual
    label: CoQ10
    status: Present — quantity not established
    amount_display: Present
    source_note: >-
      Pravst, Zmitek and Zmitek (2010), Coenzyme Q10 Contents in Foods and
      Fortification Strategies. Review Table 1 separately lists CoQ10 in sardine
      and mackerel muscle. Different muscle types and studies are not merged
      into a standard range.
    public_note: Reported in mackerel or sardine edible muscle.
    source_group: fish-coq
    public_display: internal-only
    omit_substance_card: false
    evidence_status: supported
    presence_status: presence_supported_amount_unavailable
    source_url: https://dirros.openscience.si/Dokument.php?id=36758&lang=eng
    notes: mackerel or sardine edible muscle
    source_reference: '#food-source-3'
  - key: taurine_qual
    label: Taurine
    status: Present — quantity not established
    amount_display: Present
    source_note: >-
      Extractive Nitrogenous Constituents from the Dark Muscle of Fish (1985).
      Primary abstract separately identifies taurine in common mackerel dark
      muscle; no viscera-only transfer.
    public_note: Contains taurine; content differs between dark and white muscle.
    source_group: mackerel-taurine
    public_display: internal-only
    omit_substance_card: false
    evidence_status: supported
    presence_status: presence_supported_amount_unavailable
    source_url: >-
      https://www.jstage.jst.go.jp/article/suisan1932/51/9/51_9_1461/_article/-char/en
    notes: mackerel muscle
    source_reference: '#food-source-4'
substance_relationships:
  - substance: DHA
    relationship: contains
    description: USDA FoodData Central reports DHA in Fish, mackerel, Atlantic, raw.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: mackerel|DHA
    evidence_source: USDA SR Legacy April 2018
    evidence_material: Fish, mackerel, Atlantic, raw
    source_url: https://fdc.nal.usda.gov/food-details/175119/nutrients
    presence_status: presence_and_amount_supported
    source_reference: '#food-source-5'
  - substance: EPA
    relationship: contains
    description: USDA FoodData Central reports EPA in Fish, mackerel, Atlantic, raw.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: mackerel|EPA
    evidence_source: USDA SR Legacy April 2018
    evidence_material: Fish, mackerel, Atlantic, raw
    source_url: https://fdc.nal.usda.gov/food-details/175119/nutrients
    presence_status: presence_and_amount_supported
    source_reference: '#food-source-5'
  - substance: Omega-3 Fatty Acids
    relationship: contains
    description: >-
      USDA FoodData Central reports EPA, DHA, total omega-3 in Fish, mackerel,
      Atlantic, raw. This class link does not treat a combined total as EPA, DHA
      or ALA.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: mackerel|Omega-3 Fatty Acids
    evidence_source: USDA SR Legacy April 2018
    evidence_material: Fish, mackerel, Atlantic, raw
    source_url: https://fdc.nal.usda.gov/food-details/175119/nutrients
    presence_status: presence_supported_amount_unavailable
    source_reference: '#food-source-5'
  - substance: Vitamin D
    relationship: contains
    description: USDA FoodData Central reports vitamin D in Fish, mackerel, Atlantic, raw.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: mackerel|Vitamin D
    evidence_source: USDA SR Legacy April 2018
    evidence_material: Fish, mackerel, Atlantic, raw
    source_url: https://fdc.nal.usda.gov/food-details/175119/nutrients
    presence_status: presence_and_amount_supported
    source_reference: '#food-source-5'
  - substance: CoQ10
    relationship: contains
    description: Reported in mackerel or sardine edible muscle.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: mackerel|CoQ10
    presence_status: presence_supported_amount_unavailable
    evidence_source: >-
      Pravst, Zmitek and Zmitek (2010), Coenzyme Q10 Contents in Foods and
      Fortification Strategies
    evidence_material: mackerel or sardine edible muscle
    source_url: https://dirros.openscience.si/Dokument.php?id=36758&lang=eng
    source_reference: '#food-source-3'
  - substance: Taurine
    relationship: contains
    description: Contains taurine; content differs between dark and white muscle.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: mackerel|Taurine
    presence_status: presence_supported_amount_unavailable
    evidence_source: Extractive Nitrogenous Constituents from the Dark Muscle of Fish (1985)
    evidence_material: mackerel muscle
    source_url: >-
      https://www.jstage.jst.go.jp/article/suisan1932/51/9/51_9_1461/_article/-char/en
    source_reference: '#food-source-4'
substance_review_candidates: []
---
## Overview

Mackerel is an oily fish providing complete high-quality protein together with very high levels of long-chain omega-3 fatty acids **EPA** and **DHA**, as well as **vitamin B12**, **selenium**, and other trace minerals. These intrinsic compounds support neuronal membrane phospholipid composition, mitochondrial oxidative phosphorylation, and antioxidant enzyme systems [1]. Among commonly eaten fish, mackerel is one of the richer sources of EPA and DHA per 100 g, making small portions nutritionally dense for marine omega-3 intake [1].

Within the BRAIN Diet framework, mackerel functions as a **high-omega-3 oily fish** that can be rotated with salmon, sardines, and herring rather than used as the sole source. Its protein is highly digestible, and DIAAS data for similar oily fish indicate excellent indispensable amino acid coverage

## Key Nutritional Highlights

- Provides complete, highly digestible protein.
- Commonly contributes selenium, iodine, and vitamin B12, though levels vary by species.
- EPA/DHA content is highly species-dependent; oily fish are usually higher than lean fish or shellfish.
- Often lower in saturated fat than many fatty red-meat patterns when minimally processed.
- Nutritional profile and risk context depend on processing method (fresh vs salted/smoked/cured).

## Food Context

### Sourcing

- Choose mackerel from well-managed fisheries that monitor stock status and contaminant levels; smaller pelagic species such as mackerel typically accumulate less mercury than large predatory fish.
- Where possible, prefer products with transparent sustainability certification or independent fishery assessments to support long-term availability and ecosystem health.

### Preparation

- Prefer gentle or moist-heat cooking methods (baking, steaming, stewing) to help preserve EPA/DHA and reduce lipid oxidation compared with intense high-temperature pan-frying or grilling.
- Use mackerel in modest portions within meals that also contain vegetables and whole grains, so the oily fish contributes marine omega-3s and B12 without dominating total energy or saturated fat intake.

### Essential Amino Acid Profile

This food provides a **complete essential amino acid profile** typical of animal proteins, with high digestibility and bioavailability.

## Recipes

<FoodRecipes tag="Mackerel" />

<NutritionTable details={frontMatter} />

## Substances

<FoodSubstancesFromTable details={frontMatter} />

## References

[1] These intrinsic compounds support neuronal membrane phospholipid composition, mitochondrial oxidative phosphorylation, and antioxidant enzyme systems. McNamara & Carlson 2006. [Omega-3 fatty acids in brain development, function, and psychopathology](/docs/papers/BRAIN-Diet-References#mcnamara_role_2006)

[2] Its protein is highly digestible, and DIAAS data for similar oily fish indicate excellent indispensable amino acid coverage. FAO 2013. [Dietary protein quality evaluation in human nutrition (DIAAS report)](/docs/papers/BRAIN-Diet-References#fao_diaas_2013)

<span id="food-source-3" />

[3] [Pravst, Zmitek and Zmitek (2010), Coenzyme Q10 Contents in Foods and Fortification Strategies](/docs/papers/BRAIN-Diet-References#food_composition_909fffb6dabb)

<span id="food-source-4" />

[4] [Extractive Nitrogenous Constituents from the Dark Muscle of Fish (1985)](/docs/papers/BRAIN-Diet-References#food_composition_b7f31044141a)

<span id="food-source-5" />

[5] [USDA SR Legacy April 2018](https://fdc.nal.usda.gov/food-details/175119/nutrients)
