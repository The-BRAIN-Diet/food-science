---
id: ghee
fcir_cases:
  - FCIR-006
title: Ghee
sidebar_label: Ghee
description: Heat-stable clarified butter with butyrate and fat-soluble vitamins
tags:
  - Food
  - Ghee
  - Vegetarian
  - Vitamin A
  - Vitamin E
list_image: /img/foods/ghee/ghee_thumb.webp
nutrition_per_100g:
  tyrosine_g: 0.014
  vitamin_e_mg: 2.8
  vitamin_a_rae_ug: 840
  kcal: 876
  calcium_mg: 4
  potassium_mg: 5
  zinc_mg: 0.01
  fat_g: 99.48
  caproic_g: 1.91
  capric_g: 2.495
  linoleic_g: 2.247
  vitamin_b3_mg: 0.003
  vitamin_b5_mg: 0.01
  vitamin_b6_mg: 0.001
  sat_fat_g: 61.924
  caprylic_g: 1.112
  vitamin_b1_mg: 0.001
  vitamin_b2_mg: 0.005
  vitamin_b12_ug: 0.01
  protein_g: 0.28
  phosphorus_mg: 3
  sodium_mg: 2
  copper_mg: 0.001
  beta_carotene_ug: 193
  vitamin_k_ug: 8.6
  choline_mg: 22.3
  pufa_18_3_unresolved_mg: 1447
nutrition_source:
  database: USDA FoodData Central
  food_name: 'Butter oil, anhydrous'
  fdc_id: 173412
  retrieval_method: SR Legacy bulk (April 2018)
  basis: per 100 g edible portion
  last_checked: '2026-08-15'
main_image: /img/foods/ghee/ghee_medium.webp
legacy_list_image: /img/foods/ghee/ghee_thumb.webp
legacy_main_image: /img/foods/ghee/ghee_medium.webp
nutrition_supplementary_sources:
  - key: vitamin_k2_qual
    label: Vitamin K2
    status: Present — quantity not established
    amount_display: Present — quantity not established
    source_note: >-
      Ghee is a documented dietary source of menaquinones (vitamin K2). USDA SR
      Legacy reports phylloquinone (vitamin K1), not K2, so K2 quantity is not
      established here.
    public_display: internal-only
    omit_substance_card: true
    evidence_status: unresolved
substance_relationships:
  - substance: Tyrosine
    substance_id: tyrosine
    relationship: contains
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: USDA SR Legacy April 2018
    evidence_material: "Butter oil, anhydrous"
    source_url: https://fdc.nal.usda.gov/food-details/173412/nutrients
    description: "USDA reports 14 mg tyrosine per 100 g edible portion of the specified food."
    material_limitations: "USDA SR Legacy (April 2018), food-nutrient row 1776683, nutrient 1218; No derivation code supplied in this USDA row; not asserted to be an independent assay. Data points: 0. Exact database food: Butter oil, anhydrous. Amount applies per 100 g edible portion of this recorded material, not a different species, cut or preparation. Total food tyrosine is not free supplemental L-tyrosine, absorbed dose or clinical effect."
  - substance: Retinoic acid
    relationship: dietary-precursor
    input: Preformed vitamin A (retinol and retinyl esters)
    process: 'Oxidation to retinal, then to retinoic acid'
    description: >-
      Anhydrous butter oil records 840 µg RAE vitamin A per 100 g. That is a
      retinol precursor. The food is not recorded as containing retinoic acid.
    citation_keys:
      - duester_retinoic_acid_2008
      - harrison_vitamin_a_absorption_2012
  - substance: Vitamin A
    relationship: contains
    description: >-
      USDA FoodData Central reports vitamin A as retinol activity equivalents in
      Butter oil, anhydrous.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: ghee|Vitamin A
    evidence_source: USDA SR Legacy April 2018
    evidence_material: 'Butter oil, anhydrous'
    source_url: 'https://fdc.nal.usda.gov/food-details/173412/nutrients'
    presence_status: presence_and_amount_supported
  - substance: Vitamin E
    relationship: contains
    description: 'USDA FoodData Central reports vitamin E in Butter oil, anhydrous.'
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: ghee|Vitamin E
    evidence_source: USDA SR Legacy April 2018
    evidence_material: 'Butter oil, anhydrous'
    source_url: 'https://fdc.nal.usda.gov/food-details/173412/nutrients'
    presence_status: presence_and_amount_supported
  - substance: Vitamin K2
    relationship: contains
    recovery_origin: legacy-tag-migration
    evidence_status: unresolved
    recovery_audit: ghee|Vitamin K2
    presence_status: identity_or_presence_genuinely_unresolved
    internal_review_reason: >-
      Positive ghee MK-4/MK-6 results were found in an independently published
      laboratory report, but sample definition, laboratory identity and
      analytical validation cannot be verified. Butter evidence is insufficient
      to assign ghee a quantified or established K2 claim.
substance_review_candidates:
  - Vitamin K2
---
## Overview

Ghee is clarified butter providing butyrate, vitamins A/D/E, and heat stability, making it suitable for high-heat cooking.

Within the BRAIN Diet framework, ghee provides butyrate, vitamins A/D/E, is heat-stable, and low in lactose/casein, making it suitable for high-heat cooking and Ayurvedic dishes.

## Food Context

### Synergies

- Part of stable cooking fat strategy

### Preparation

- Heat-stable for high-heat cooking
- Low in lactose/casein (suitable for some sensitivities)
- Supports butyrate intake

## Recipes

<FoodRecipes tag="Ghee" />

<NutritionTable details={frontMatter} />

## Substances

<FoodSubstancesFromTable details={frontMatter} />

## References

[1] Grass-fed dairy fats differ in fatty-acid profile from conventional dairy, including CLA content. Daley et al. 2010. [A review of nutritional differences between grass-fed and grain-fed beef](/docs/papers/BRAIN-Diet-References#daley_grassfed_2010)

[2] Short-chain fatty acids from saturated fats and fermentation support colonic and metabolic health context. Rose et al. 2018. [Butyrate enhances mitochondrial function during oxidative stress in cell lines from boys with autism](/docs/papers/BRAIN-Diet-References#rose_butyrate_2018)
