---
id: cod
title: Cod
sidebar_label: Cod
description: 'Lean fish with omega-3, taurine, and creatine'
tags:
  - Food
  - Cod
  - Omega-3 Fatty Acids
list_image: /img/foods/cod/cod_thumb.webp
nutrition_per_100g:
  tyrosine_g: 0.601
  choline_mg: 65.2
  vitamin_e_mg: 0.64
  kcal: 82
  vitamin_k_ug: 0.1
  vitamin_a_rae_ug: 12
  vitamin_d_ug: 0.9
  iron_mg: 0.38
  magnesium_mg: 32
  phosphorus_mg: 203
  sodium_mg: 54
  copper_mg: 0.028
  manganese_mg: 0.015
  vitamin_c_mg: 1
  vitamin_b1_mg: 0.076
  vitamin_b2_mg: 0.065
  folate_ug: 7
  vitamin_b12_ug: 0.91
  protein_g: 17.81
  sat_fat_g: 0.131
  dha_mg: 120
  epa_mg: 64
  fat_g: 0.67
  vitamin_b3_mg: 2.063
  vitamin_b5_mg: 0.153
  vitamin_b6_mg: 0.245
  calcium_mg: 16
  potassium_mg: 413
  zinc_mg: 0.45
  linoleic_g: 0.005
  selenium_ug: 33.1
  omega3_mg: 194
  pufa_18_3_unresolved_mg: 1
omega3_components:
  - nutrient: dha_mg
    identity: '22:6 n-3 (DHA)'
    amount_mg: 120
  - nutrient: epa_mg
    identity: '20:5 n-3 (EPA)'
    amount_mg: 64
  - nutrient: dpa_mg
    identity: '22:5 n-3 (DPA)'
    amount_mg: 10
nutrition_source:
  database: USDA FoodData Central
  food_name: 'Fish, cod, Atlantic, raw'
  fdc_id: 171955
  retrieval_method: SR Legacy bulk (April 2018)
  basis: per 100 g edible portion
  last_checked: '2026-08-15'
protein_profile_note: Complete essential amino acid profile.
main_image: /img/foods/cod/cod_medium.webp
legacy_list_image: /img/foods/cod/cod_thumb.webp
legacy_main_image: /img/foods/cod/cod_medium.webp
substance_relationships:
  - substance: Tyrosine
    substance_id: tyrosine
    relationship: contains
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: USDA SR Legacy April 2018
    evidence_material: "Fish, cod, Atlantic, raw"
    source_url: https://fdc.nal.usda.gov/food-details/171955/nutrients
    description: "USDA reports 601 mg tyrosine per 100 g edible portion of the specified food."
    material_limitations: "USDA SR Legacy (April 2018), food-nutrient row 1653419, nutrient 1218; No derivation code supplied in this USDA row; not asserted to be an independent assay. Data points: 0. Exact database food: Fish, cod, Atlantic, raw. Amount applies per 100 g edible portion of this recorded material, not a different species, cut or preparation. Total food tyrosine is not free supplemental L-tyrosine, absorbed dose or clinical effect."
  - substance: Omega-3 Fatty Acids
    relationship: contains
    description: >-
      USDA FoodData Central reports EPA, DHA, total omega-3 in Fish, cod,
      Atlantic, raw. This class link does not treat a combined total as EPA, DHA
      or ALA.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: cod|Omega-3 Fatty Acids
    evidence_source: USDA SR Legacy April 2018
    evidence_material: 'Fish, cod, Atlantic, raw'
    source_url: 'https://fdc.nal.usda.gov/food-details/171955/nutrients'
    presence_status: presence_supported_amount_unavailable
substance_review_candidates: []
---
## Overview

Cod is a lean white fish providing modest amounts of **omega-3 fatty acids**, **vitamin B12**, **selenium**, and other trace minerals, together with highly digestible protein. Compared with oily fish such as salmon or mackerel, cod contributes smaller absolute amounts of EPA and DHA but still adds marine omega-3s, micronutrients, and protein at a relatively low energy cost [1]. This makes cod useful in meals where the focus is on vegetables and whole grains, with fish acting as a lighter protein component.

Within the BRAIN Diet framework, cod functions as a **lean marine protein** that can be rotated with higher-fat oily fish rather than replacing them. Its protein has a high digestible indispensable amino acid score (DIAAS), indicating excellent indispensable amino acid coverage [2]. This makes cod a flexible option when meals already provide substantial fats from other ingredients, allowing marine protein and modest omega-3 intake without substantially increasing total dietary fat.

## Key Nutritional Highlights

- Provides complete, highly digestible protein with excellent DIAAS coverage [2].
- Modest EPA/DHA relative to oily fish; still contributes marine omega-3s at low energy cost [1].
- Selenium and vitamin B12 vary by species; see nutrition table for this FDC entry.
- Lean marine protein (~61 kcal per 100 g) for meals already containing other fat sources [1].

## Food Context

### Sourcing

- Choose cod from fisheries with transparent stock assessments and sustainability practices; colder-water wild-caught cod from well-managed stocks can be a relatively low-impact choice [1,2].
- As a lower-trophic species relative to large predatory fish, cod generally accumulates less mercury, but it should still be consumed as part of a varied fish intake pattern for both sustainability and risk management [1,2].

### Essential Amino Acid Profile

This food provides a complete essential amino acid profile typical of animal proteins.

## Recipes

<FoodRecipes tag="Cod" />

<NutritionTable details={frontMatter} />

## Substances

<FoodSubstancesFromTable details={frontMatter} />

## References

[1] Lean marine protein (~61 kcal per 100 g) for meals already containing other fat sources. McNamara & Carlson 2006. [Role of omega-3 fatty acids in brain development and function: Potential implications for the pathogenesis and prevention of psychopathology](/docs/papers/BRAIN-Diet-References#mcnamara_role_2006)

[2] Provides complete, highly digestible protein with excellent DIAAS coverage. FAO 2013. [Dietary Protein Quality Evaluation in Human Nutrition: Report of an FAO Expert Consultation](/docs/papers/BRAIN-Diet-References#fao_diaas_2013)
