---
id: chicory-root
title: Chicory Root
sidebar_label: Chicory Root
description: Raw root with measured fructans, reported separately from fructooligosaccharides
tags:
  - Food
  - Chicory Root
  - Vegan
  - Vegetarian
list_image: /img/foods/chicory-root/chicory-root_thumb.webp
nutrition_per_100g:
  kcal: 72
  protein_g: 1.4
  fat_g: 0.2
  carbs_g: 17.51
  sugar_g: 8.73
  fibre_g: 1.5
  sodium_mg: 50
  potassium_mg: 290
  calcium_mg: 41
  iron_mg: 0.8
  magnesium_mg: 22
  phosphorus_mg: 61
  zinc_mg: 0.33
  copper_mg: 0.077
  manganese_mg: 0.233
  selenium_ug: 0.7
  vitamin_c_mg: 5
  vitamin_b3_mg: 0.4
  vitamin_b5_mg: 0.323
  vitamin_b6_mg: 0.241
  folate_ug: 23
nutrition_source:
  database: USDA SR Legacy, FDC 169993
  food_name: Chicory roots, raw (Cichorium intybus)
  fdc_id: 169993
  basis: per 100 g edible portion; dietary fibre does not include inulin
  source_url: https://tools.myfooddata.com/nutrition-facts/169993/wt1
  source_reference: '#food-source-3'
  last_checked: '2026-10-12'
composition_status: supported
composition_technical_provenance:
  source_record: >-
    USDA SR Legacy FDC 169993, NDB 11154, Chicory roots, raw. MyFoodData shows
    this record per 60 g root. The table uses the per 100 g amounts. FDC 169992
    remains barred: it is chicory greens.
  carbohydrate_identity: >-
    Carbohydrate 17.51 g is carbohydrate by difference. Protein 1.4 g is the
    published protein; the record states a nitrogen-to-protein factor of 6.25.
  fibre_identity: >-
    Dietary fibre is 1.5 g per 100 g. Inulin is not part of that fibre value.
  omitted_small_amounts: >-
    Saturated fat 0.048 g, thiamin 0.04 mg and riboflavin 0.03 mg per 100 g are
    in the record. They are omitted here because one-decimal display would show
    them as zero. Vitamin A is 6 IU; retinol activity equivalents are not entered.
  fatty_acid_identity: >-
    18:1 undifferentiated, 18:2 undifferentiated and 18:3 undifferentiated are not
    published as oleic acid, linoleic acid or ALA. MyFoodData omega-3 and
    omega-6 rows extrapolated from those undifferentiated acids are not used.
eaa_profile_applicable: false
nutrition_supplementary_sources:
  - key: fructans_jovanovic
    label: Fructans
    value: 8.4
    unit: g
    basis: per 100 g fresh weight
    amount_display: 8.40 ± 0.186 g per 100 g fresh weight
    public_display: table
    evidence_status: supported
    source_url: https://doi.org/10.1080/10942912.2012.680221
    evidence_material: Chicory root
    preparation_state: Fresh weight as reported. Cultivar and further preparation are not stated in the abstract.
    source_note: >-
      Jovanovic-Malinovska et al. 2014 reported chicory-root fructans at
      8.40 ± 0.186 g per 100 g fresh weight, separately from the
      fructooligosaccharide figures in the same paper. This is not an
      oligofructose amount, not galacto-oligosaccharides, and not the combined
      experimental preparation.
    public_note: >-
      Fructans, 8.40 ± 0.186 g per 100 g fresh weight. Not a fructooligosaccharide
      amount and not a combined fructo-oligosaccharide plus galacto-oligosaccharide amount.
    source_group: Jovanovic-Malinovska et al. 2014
substance_relationships:
  - substance: Fructans
    relationship: contains
    requires_supplementary_key: fructans_jovanovic
    description: >-
      Jovanovic-Malinovska et al. 2014 reported fructans at 8.40 ± 0.186 g per
      100 g fresh weight in chicory root. The paper reports this separately
      from fructooligosaccharides.
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: Jovanovic-Malinovska et al. 2014
    evidence_material: Chicory root
    preparation_state: Fresh weight as reported. Cultivar and further preparation are not stated in the abstract.
    source_url: https://doi.org/10.1080/10942912.2012.680221
    citation_keys:
      - jovanovic_malinovska_food_oligosaccharides_2014
    chemical_form: Fructans, reported separately from fructooligosaccharides
    material_limitations: >-
      Not oligofructose, not fructo-oligosaccharides, not galacto-oligosaccharides,
      and not the combined experimental preparation. USDA dietary fibre on this
      page does not include this fructan figure.
  - substance: Iron
    relationship: contains
    description: "USDA SR Legacy, FDC 169993 reports 0.8 mg iron per 100 g edible portion in Chicory roots, raw (Cichorium intybus)."
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: "USDA SR Legacy, FDC 169993"
    evidence_material: "Chicory roots, raw (Cichorium intybus)"
    source_url: "https://tools.myfooddata.com/nutrition-facts/169993/wt1"
  - substance: Vitamin B6
    relationship: contains
    description: "USDA SR Legacy, FDC 169993 reports 0.241 mg vitamin B6 per 100 g edible portion in Chicory roots, raw (Cichorium intybus)."
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: "USDA SR Legacy, FDC 169993"
    evidence_material: "Chicory roots, raw (Cichorium intybus)"
    source_url: "https://tools.myfooddata.com/nutrition-facts/169993/wt1"
  - substance: Copper
    relationship: contains
    description: "USDA SR Legacy, FDC 169993 reports 0.077 mg copper per 100 g edible portion in Chicory roots, raw (Cichorium intybus)."
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: "USDA SR Legacy, FDC 169993"
    evidence_material: "Chicory roots, raw (Cichorium intybus)"
    source_url: "https://tools.myfooddata.com/nutrition-facts/169993/wt1"
  - substance: Vitamin C
    relationship: contains
    description: "USDA SR Legacy, FDC 169993 reports 5 mg vitamin C per 100 g edible portion in Chicory roots, raw (Cichorium intybus)."
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: "USDA SR Legacy, FDC 169993"
    evidence_material: "Chicory roots, raw (Cichorium intybus)"
    source_url: "https://tools.myfooddata.com/nutrition-facts/169993/wt1"
  - substance: Vitamin B9
    relationship: contains
    description: "USDA SR Legacy, FDC 169993 reports 23 µg folate per 100 g edible portion in Chicory roots, raw (Cichorium intybus)."
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: "USDA SR Legacy, FDC 169993"
    evidence_material: "Chicory roots, raw (Cichorium intybus)"
    source_url: "https://tools.myfooddata.com/nutrition-facts/169993/wt1"
  - substance: Selenium
    relationship: contains
    description: "USDA SR Legacy, FDC 169993 reports 0.7 µg selenium per 100 g edible portion in Chicory roots, raw (Cichorium intybus)."
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: "USDA SR Legacy, FDC 169993"
    evidence_material: "Chicory roots, raw (Cichorium intybus)"
    source_url: "https://tools.myfooddata.com/nutrition-facts/169993/wt1"
  - substance: Zinc
    relationship: contains
    description: "USDA SR Legacy, FDC 169993 reports 0.33 mg zinc per 100 g edible portion in Chicory roots, raw (Cichorium intybus)."
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: "USDA SR Legacy, FDC 169993"
    evidence_material: "Chicory roots, raw (Cichorium intybus)"
    source_url: "https://tools.myfooddata.com/nutrition-facts/169993/wt1"
  - substance: Magnesium
    relationship: contains
    description: "USDA SR Legacy, FDC 169993 reports 22 mg magnesium per 100 g edible portion in Chicory roots, raw (Cichorium intybus)."
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: "USDA SR Legacy, FDC 169993"
    evidence_material: "Chicory roots, raw (Cichorium intybus)"
    source_url: "https://tools.myfooddata.com/nutrition-facts/169993/wt1"
main_image: /img/foods/chicory-root/chicory-root_medium.webp
legacy_list_image: /img/foods/chicory-root/chicory-root_thumb.webp
legacy_main_image: /img/foods/chicory-root/chicory-root_medium.webp
---
## Overview

Chicory root contains **fructans** at 8.40 ± 0.186 g per 100 g fresh weight. That figure is reported separately from fructooligosaccharides and is not a combined fructo-oligosaccharide and galacto-oligosaccharide amount [4]. The nutrient table is raw chicory root. Dietary fibre in that table is 1.5 g per 100 g and does not include inulin. Prebiotic fibres have been studied for gut–brain axis markers including cortisol response [2].

Within the BRAIN Diet framework, chicory root (and inulin ingredients) support fermentable-fibre diversity; typical use is as roasted drink or inulin additive rather than whole-root bulk intake [1,2].

## Key Nutritional Highlights

- Fructans, 8.40 ± 0.186 g per 100 g fresh weight, reported separately from fructooligosaccharides [4]. The table’s 1.5 g fibre is dietary fibre and does not include this fructan figure.
- Prebiotic intake studied for cortisol and emotional-bias endpoints [2].
- Roasted chicory beverage is caffeine-free coffee substitute.
- Introduce gradually to limit fermentative GI discomfort.

## Food Context

### Synergies

- Part of diverse prebiotic fiber strategy

### Preparation

- Can be consumed as root vegetable or coffee substitute
- High inulin content
- Supports Bifidobacterium and Akkermansia

## Recipes

<FoodRecipes tag="Chicory Root" />

<NutritionTable details={frontMatter} />

## Substances

<FoodSubstancesFromTable details={frontMatter} />

## References

[1] High inulin content — fermentable prebiotic fibre. Pouille & Ouaza 2022. [Chicory: Understanding the Effects and Effectors of This Functional Food](/docs/papers/BRAIN-Diet-References#pouille_chicory_2022)

[2] Prebiotic intake studied for cortisol and emotional-bias endpoints. Schmidt & Cowen 2015. [Prebiotic intake reduces the waking cortisol response and alters emotional bias in healthy volunteers](/docs/papers/BRAIN-Diet-References#schmidt_prebiotic_2015)

<span id="food-source-3" />

[3] [Chicory roots, raw (Cichorium intybus), USDA SR Legacy FDC 169993](https://tools.myfooddata.com/nutrition-facts/169993/wt1)

[4] Jovanovic-Malinovska et al. (2014). [Oligosaccharide profile in fruits and vegetables as sources of prebiotics and functional foods](/docs/papers/BRAIN-Diet-References#jovanovic_malinovska_food_oligosaccharides_2014). Chicory-root fructans were 8.40 ± 0.186 g per 100 g fresh weight, reported separately from fructooligosaccharides.
