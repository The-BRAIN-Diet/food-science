---
id: egg-yolks
title: Egg Yolks
sidebar_label: Egg Yolks
description: Nutrient-dense part of eggs with choline, lutein, and fat-soluble vitamins
tags:
  - Food
  - Egg Yolks
  - Vegetarian
  - Choline
  - Lutein
  - Zeaxanthin
  - Carotenoid
  - Vitamin A
  - Vitamin D
  - Vitamin E
  - Vitamin K2
list_image: /img/foods/egg-yolks/egg-yolks_thumb.webp
nutrition_per_100g:
  tyrosine_g: 0.678
  vitamin_e_mg: 2.58
  sugar_g: 0.56
  lutein_zeaxanthin_ug: 1094
  vitamin_b5_mg: 2.99
  manganese_mg: 0.055
  beta_carotene_ug: 88
  vitamin_k_ug: 0.7
  vitamin_b3_mg: 0.024
  calcium_mg: 129
  potassium_mg: 109
  zinc_mg: 2.3
  selenium_ug: 56
  fat_g: 26.54
  vitamin_b6_mg: 0.35
  protein_g: 15.86
  iron_mg: 2.73
  magnesium_mg: 5
  phosphorus_mg: 390
  sodium_mg: 48
  copper_mg: 0.077
  vitamin_b1_mg: 0.176
  vitamin_b2_mg: 0.528
  vitamin_b12_ug: 1.95
  choline_mg: 820.2
  carbs_g: 3.59
  kcal: 322
  sat_fat_g: 9.551
  vitamin_a_rae_ug: 381
  vitamin_d_ug: 5.4
  capric_g: 0.009
  linoleic_g: 3.538
  folate_ug: 146
  caprylic_g: 0.009
  dha_mg: 114
  epa_mg: 11
  omega3_mg: 125
  pufa_18_3_unresolved_mg: 103
omega3_components:
  - nutrient: dha_mg
    identity: 22:6 n-3 (DHA)
    amount_mg: 114
  - nutrient: epa_mg
    identity: 20:5 n-3 (EPA)
    amount_mg: 11
nutrition_source:
  database: USDA FoodData Central
  food_name: Egg, yolk, raw, fresh
  fdc_id: 172184
  retrieval_method: SR Legacy bulk (April 2018)
  basis: per 100 g edible portion
  last_checked: '2026-08-15'
protein_profile_note: Complete essential amino acid profile.
main_image: /img/foods/egg-yolks/egg-yolks_medium.webp
legacy_list_image: /img/foods/egg-yolks/egg-yolks_thumb.webp
legacy_main_image: /img/foods/egg-yolks/egg-yolks_medium.webp
nutrition_supplementary_sources:
  - key: vitamin_k2_qual
    label: Vitamin K2
    status: Present — quantity not established
    amount_display: Present
    source_note: >-
      Schurgers and Vermeer (2000), Determination of phylloquinone and
      menaquinones in food. Primary abstract explicitly identifies K2 in butter,
      egg yolk, natto and cheese. No total vitamin K value used as K2.
    public_display: table
    omit_substance_card: false
    evidence_status: supported
    presence_status: presence_supported_amount_unavailable
    source_url: https://pubmed.ncbi.nlm.nih.gov/11356998/
    source_group: vitamin-k2
    public_note: Contains menaquinones (vitamin K2); the amount is product-dependent.
    notes: butter, egg yolk or fermented soybean food
    source_reference: '#food-source-4'
substance_relationships:
  - substance: Tyrosine
    substance_id: tyrosine
    relationship: contains
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: USDA SR Legacy April 2018
    evidence_material: "Egg, yolk, raw, fresh"
    source_url: https://fdc.nal.usda.gov/food-details/172184/nutrients
    description: "USDA reports 678 mg tyrosine per 100 g edible portion of the specified food."
    material_limitations: "USDA SR Legacy (April 2018), food-nutrient row 1674750, nutrient 1218; Analytical. Data points: 0. Exact database food: Egg, yolk, raw, fresh. Amount applies per 100 g edible portion of this recorded material, not a different species, cut or preparation. Total food tyrosine is not free supplemental L-tyrosine, absorbed dose or clinical effect."
  - substance: Retinoic acid
    relationship: dietary-precursor
    input: Preformed vitamin A (retinol and retinyl esters)
    process: Oxidation to retinal, then to retinoic acid
    description: >-
      Raw egg yolk records 381 µg RAE vitamin A per 100 g and 88 µg
      beta-carotene. The dominant precursor is preformed vitamin A. The food is
      not recorded as containing retinoic acid.
    citation_keys:
      - duester_retinoic_acid_2008
      - harrison_vitamin_a_absorption_2012
  - substance: Choline
    relationship: contains
    description: USDA FoodData Central reports choline in Egg, yolk, raw, fresh.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: egg-yolks|Choline
    evidence_source: USDA SR Legacy April 2018
    evidence_material: Egg, yolk, raw, fresh
    source_url: https://fdc.nal.usda.gov/food-details/172184/nutrients
    presence_status: presence_and_amount_supported
    source_reference: '#food-source-5'
  - substance: Vitamin A
    relationship: contains
    description: >-
      USDA FoodData Central reports vitamin A as retinol activity equivalents in
      Egg, yolk, raw, fresh.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: egg-yolks|Vitamin A
    evidence_source: USDA SR Legacy April 2018
    evidence_material: Egg, yolk, raw, fresh
    source_url: https://fdc.nal.usda.gov/food-details/172184/nutrients
    presence_status: presence_and_amount_supported
    source_reference: '#food-source-5'
  - substance: Vitamin D
    relationship: contains
    description: USDA FoodData Central reports vitamin D in Egg, yolk, raw, fresh.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: egg-yolks|Vitamin D
    evidence_source: USDA SR Legacy April 2018
    evidence_material: Egg, yolk, raw, fresh
    source_url: https://fdc.nal.usda.gov/food-details/172184/nutrients
    presence_status: presence_and_amount_supported
    source_reference: '#food-source-5'
  - substance: Vitamin E
    relationship: contains
    description: USDA FoodData Central reports vitamin E in Egg, yolk, raw, fresh.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: egg-yolks|Vitamin E
    evidence_source: USDA SR Legacy April 2018
    evidence_material: Egg, yolk, raw, fresh
    source_url: https://fdc.nal.usda.gov/food-details/172184/nutrients
    presence_status: presence_and_amount_supported
    source_reference: '#food-source-5'
  - substance: Vitamin K2
    relationship: contains
    description: Contains menaquinones (vitamin K2); the amount is product-dependent.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: egg-yolks|Vitamin K2
    presence_status: presence_supported_amount_unavailable
    evidence_source: >-
      Schurgers and Vermeer (2000), Determination of phylloquinone and
      menaquinones in food
    evidence_material: butter, egg yolk or fermented soybean food
    source_url: https://pubmed.ncbi.nlm.nih.gov/11356998/
    source_reference: '#food-source-4'
  - substance: Zeaxanthin
    relationship: contains
    description: >-
      Sommerburg et al. (1998) identified zeaxanthin in studied egg yolk. A
      separate amount for this page’s preparation is not established.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: egg-yolks|Zeaxanthin
    evidence_source: Sommerburg et al. (1998), Table 1
    evidence_material: Studied egg yolk
    source_url: https://www.kinkiagri.or.jp/CropFFF/vegetables/Pdf/zeaxanthin1.pdf
    presence_status: presence_supported_amount_unavailable
    source_reference: '#food-source-6'
  - substance: Lutein
    relationship: contains
    description: >-
      Sommerburg et al. (1998) identified lutein in studied egg yolk. A separate
      amount for this page’s preparation is not established.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: egg-yolks|Lutein
    evidence_source: Sommerburg et al. (1998), Table 1
    evidence_material: Studied egg yolk
    source_url: https://www.kinkiagri.or.jp/CropFFF/vegetables/Pdf/zeaxanthin1.pdf
    presence_status: presence_supported_amount_unavailable
    source_reference: '#food-source-6'
substance_review_candidates: []
---
## Overview

Egg yolks provide choline (acetylcholine precursor), lutein and zeaxanthin [3], and fat-soluble vitamins (A, D, E, K2), supporting neurotransmitter synthesis and brain health. The 1,094 µg per 100 g on this page is USDA lutein plus zeaxanthin, not a zeaxanthin amount.

Within the BRAIN Diet framework, acetylcholine and choline food sources include egg yolks, fish roe, soy, wheat germ, and liver.

## Food Context

### Synergies

- Pair with carotenoid-rich vegetables; yolk phospholipids help absorb the vegetables’ carotenoids [2].

### Sourcing

- Choose pasture-raised for higher nutrient content

### Preparation

- Yolk **lutein** and **zeaxanthin** are highly bioavailable xanthophylls. Boiling, frying, and microwaving change isomer profiles and reduce total yolk xanthophyll content by about **6–18%** (all-E-lutein most affected in boiled yolk); cooked yolks show more Z-isomers [1].
- Gentle cooking preserves choline and limits excessive heat damage.

### Essential Amino Acid Profile

This food provides a complete essential amino acid profile typical of animal proteins.

## Recipes

<FoodRecipes tag="Egg Yolks" />

<NutritionTable details={frontMatter} />

## Substances

<FoodSubstancesFromTable details={frontMatter} />

## References

[1] Yolk **lutein** and **zeaxanthin** are highly bioavailable xanthophylls. Boiling, frying, and microwaving change isomer profiles and reduce total yolk xanthophyll content by about **6–18%** (all-E-lutein most affected in boiled yolk); cooked yolks show more Z-isomers. Nimalaratne & Lopes-Lutz 2012. [Domestic cooking methods and egg yolk xanthophylls](/docs/papers/BRAIN-Diet-References#nimalaratne_cooking_2012)

[2] Kim et al. (2015). [Effects of egg consumption on carotenoid absorption from co-consumed, raw vegetables](/docs/papers/BRAIN-Diet-References#kim_egg_carotenoid_2015). Randomized crossover in 16 healthy young men: 150 g scrambled whole eggs (~3 eggs) with a raw mixed salad increased TRL carotenoid AUC versus no egg (lutein and zeaxanthin 4- to 5-fold; α-carotene, β-carotene and lycopene 3- to 8-fold). The authors discuss yolk phospholipids as well as total yolk lipid as promoters of micellarization; the trial used whole eggs and did not isolate phospholipids from triglycerides.

[3] Eisenhauer et al. (2017). [Lutein and Zeaxanthin—Food Sources, Bioavailability and Dietary Variety in Age-Related Macular Degeneration Protection](/docs/papers/BRAIN-Diet-References#eisenhauer_lutein_zeaxanthin_2017). Table 4 reports 762 µg trans-zeaxanthin and 787 µg trans-lutein per 100 g in the raw egg yolk measured by Perry et al. (2009).

<span id="food-source-4" />

[4] [Schurgers and Vermeer (2000), Determination of phylloquinone and menaquinones in food](/docs/papers/BRAIN-Diet-References#food_composition_a955736e9d48)

<span id="food-source-5" />

[5] [USDA SR Legacy April 2018](https://fdc.nal.usda.gov/food-details/172184/nutrients)

<span id="food-source-6" />

[6] [Sommerburg et al. (1998), Table 1](https://www.kinkiagri.or.jp/CropFFF/vegetables/Pdf/zeaxanthin1.pdf)
