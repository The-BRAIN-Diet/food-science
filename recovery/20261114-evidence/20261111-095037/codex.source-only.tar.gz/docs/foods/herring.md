---
id: herring
title: Herring
sidebar_label: Herring
description: Oily fish rich in EPA/DHA omega-3s
tags:
  - Food
  - Herring
  - Omega-3 Fatty Acids
  - EPA
  - DHA
  - Vitamin D
list_image: /img/foods/herring/herring_thumb.webp
nutrition_per_100g:
  tyrosine_g: 0.606
  vitamin_k_ug: 0.1
  vitamin_e_mg: 1.07
  vitamin_d_ug: 4.2
  vitamin_a_rae_ug: 28
  choline_mg: 65
  protein_g: 17.96
  iron_mg: 1.1
  magnesium_mg: 32
  phosphorus_mg: 236
  sodium_mg: 90
  copper_mg: 0.092
  manganese_mg: 0.035
  dha_mg: 862
  epa_mg: 709
  sat_fat_g: 2.04
  vitamin_c_mg: 0.7
  vitamin_b1_mg: 0.092
  vitamin_b2_mg: 0.233
  folate_ug: 10
  vitamin_b12_ug: 13.67
  fat_g: 9.04
  kcal: 158
  vitamin_b3_mg: 3.217
  vitamin_b5_mg: 0.645
  vitamin_b6_mg: 0.302
  calcium_mg: 57
  potassium_mg: 327
  zinc_mg: 0.99
  capric_g: 0.005
  linoleic_g: 0.13
  selenium_ug: 36.5
  omega3_mg: 1626
  pufa_18_3_unresolved_mg: 103
omega3_components:
  - nutrient: dha_mg
    identity: '22:6 n-3 (DHA)'
    amount_mg: 862
  - nutrient: epa_mg
    identity: '20:5 n-3 (EPA)'
    amount_mg: 709
  - nutrient: dpa_mg
    identity: '22:5 n-3 (DPA)'
    amount_mg: 55
nutrition_source:
  database: USDA FoodData Central
  food_name: 'Fish, herring, Atlantic, raw'
  fdc_id: 175116
  retrieval_method: SR Legacy bulk (April 2018)
  basis: per 100 g edible portion
  last_checked: '2026-08-15'
main_image: /img/foods/herring/herring_medium.webp
legacy_list_image: /img/foods/herring/herring_thumb.webp
legacy_main_image: /img/foods/herring/herring_medium.webp
protein_profile_note: Complete essential amino acid profile.
substance_relationships:
  - substance: Tyrosine
    substance_id: tyrosine
    relationship: contains
    evidence_status: supported
    presence_status: presence_and_amount_supported
    evidence_source: USDA SR Legacy April 2018
    evidence_material: "Fish, herring, Atlantic, raw"
    source_url: https://fdc.nal.usda.gov/food-details/175116/nutrients
    description: "USDA reports 606 mg tyrosine per 100 g edible portion of the specified food."
    material_limitations: "USDA SR Legacy (April 2018), food-nutrient row 1913685, nutrient 1218; No derivation code supplied in this USDA row; not asserted to be an independent assay. Data points: 0. Exact database food: Fish, herring, Atlantic, raw. Amount applies per 100 g edible portion of this recorded material, not a different species, cut or preparation. Total food tyrosine is not free supplemental L-tyrosine, absorbed dose or clinical effect."
  - substance: DHA
    relationship: contains
    description: 'USDA FoodData Central reports DHA in Fish, herring, Atlantic, raw.'
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: herring|DHA
    evidence_source: USDA SR Legacy April 2018
    evidence_material: 'Fish, herring, Atlantic, raw'
    source_url: 'https://fdc.nal.usda.gov/food-details/175116/nutrients'
    presence_status: presence_and_amount_supported
  - substance: EPA
    relationship: contains
    description: 'USDA FoodData Central reports EPA in Fish, herring, Atlantic, raw.'
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: herring|EPA
    evidence_source: USDA SR Legacy April 2018
    evidence_material: 'Fish, herring, Atlantic, raw'
    source_url: 'https://fdc.nal.usda.gov/food-details/175116/nutrients'
    presence_status: presence_and_amount_supported
  - substance: Omega-3 Fatty Acids
    relationship: contains
    description: >-
      USDA FoodData Central reports EPA, DHA, total omega-3 in Fish, herring,
      Atlantic, raw. This class link does not treat a combined total as EPA, DHA
      or ALA.
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: herring|Omega-3 Fatty Acids
    evidence_source: USDA SR Legacy April 2018
    evidence_material: 'Fish, herring, Atlantic, raw'
    source_url: 'https://fdc.nal.usda.gov/food-details/175116/nutrients'
    presence_status: presence_supported_amount_unavailable
  - substance: Vitamin D
    relationship: contains
    description: 'USDA FoodData Central reports vitamin D in Fish, herring, Atlantic, raw.'
    recovery_origin: legacy-tag-migration
    evidence_status: supported
    recovery_audit: herring|Vitamin D
    evidence_source: USDA SR Legacy April 2018
    evidence_material: 'Fish, herring, Atlantic, raw'
    source_url: 'https://fdc.nal.usda.gov/food-details/175116/nutrients'
    presence_status: presence_and_amount_supported
substance_review_candidates: []
---
## Overview

Herring is a small oily fish providing high levels of long-chain omega-3 fatty acids **EPA** and **DHA**, **vitamin D**, trace minerals such as **selenium**, and highly bioavailable protein. These intrinsic nutrients contribute to neuronal membrane phospholipid composition, mitochondrial oxidative metabolism, and anti-inflammatory lipid mediator production [1]. Because herring is usually eaten as fillets rather than as oil alone, typical portions deliver marine omega-3s alongside protein and micronutrients rather than isolated fat.

Within the BRAIN Diet framework, herring is treated as one of the **rotational oily fish options** alongside salmon, mackerel, and sardines. Regular intake of oily fish rich in EPA and DHA is associated with cardiometabolic benefits and may support aspects of cognitive and mood outcomes [1,2]. As a relatively small pelagic species, herring tends to accumulate less mercury than large predatory fish, which supports its use as a frequent marine omega-3 source within a varied dietary pattern

## Key Nutritional Highlights

- Provides complete, highly digestible protein.
- Commonly contributes selenium, iodine, and vitamin B12, though levels vary by species.
- EPA/DHA content is highly species-dependent; oily fish are usually higher than lean fish or shellfish.
- Often lower in saturated fat than many fatty red-meat patterns when minimally processed.
- Nutritional profile and risk context depend on processing method (fresh vs salted/smoked/cured).

## Food Context

### Sourcing

- Choose herring from fisheries with transparent sustainability assessments and contaminant monitoring; smaller pelagic species such as herring typically have lower mercury levels than large predatory fish.
- Lightly processed forms (fresh, frozen, or simply cured) are preferable to heavily sweetened or ultra-processed preparations where possible.

### Preparation

- Prefer gentle or moist-heat cooking methods (baking, steaming, stewing) to preserve EPA/DHA and reduce oxidation compared with intense high-temperature frying.
- Incorporate herring into meals that also contain vegetables and whole grains so that oily fish contributes marine omega-3s and vitamin D within a balanced plate.

## Recipes

<FoodRecipes tag="Herring" />

### Essential Amino Acid Profile

This food provides a complete essential amino acid profile typical of animal proteins.

<NutritionTable details={frontMatter} />

## Substances

<FoodSubstancesFromTable details={frontMatter} />

## References

[1] These intrinsic nutrients contribute to neuronal membrane phospholipid composition, mitochondrial oxidative metabolism, and anti-inflammatory lipid mediator production. McNamara & Carlson 2006. [Omega-3 fatty acids in brain development, function, and psychopathology](/docs/papers/BRAIN-Diet-References#mcnamara_role_2006)

[2] DHA supplementation improved both memory and reaction time in healthy young adults: a randomized controlled trial. Stonehouse et al. 2013. [DHA supplementation and cognitive performance in healthy adults](/docs/papers/BRAIN-Diet-References#stonehouse_dha_2013)

[3] As a relatively small pelagic species, herring tends to accumulate less mercury than large predatory fish, which supports its use as a frequent marine omega-3 source within a varied dietary pattern. FAO 2013. [Dietary protein quality evaluation in human nutrition (DIAAS report)](/docs/papers/BRAIN-Diet-References#fao_diaas_2013)
