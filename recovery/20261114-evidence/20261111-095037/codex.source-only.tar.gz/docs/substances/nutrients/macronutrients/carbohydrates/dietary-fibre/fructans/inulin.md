---
id: inulin
title: Inulin
sidebar_label: Inulin
description: Longer-chain inulin-type fructan. The mouse mucus result used oligofructose-enriched inulin, which is not inulin alone and not oligofructose alone.
tags:
  - Substance
  - Nutrient
  - Carbohydrate
  - Dietary Fibre
  - Fructan
  - Inulin
  - Gut-Brain Axis & Enteric Nervous System
mechanisms:
  Gut-Brain Axis & Enteric Nervous System: 'Oligofructose-enriched inulin prevented a Western-diet increase in inner-colonic mucus penetrability in mice. That mixture is not inulin alone and not oligofructose alone.'
list_image: /img/icons/nutrient.svg
---

## Overview

Inulin is the longer-chain member of the inulin-type fructans, linear fructose polymers with a degree of polymerisation often described around 10–60. [Oligofructose](/docs/substances/nutrients/macronutrients/carbohydrates/dietary-fibre/fructans/oligofructose) is the short-chain mixture, about 2–8 or, in another convention, up to 10. Oligofructose-enriched inulin is a blend of the two. The names are not interchangeable [1,2].

In mice fed a Western diet, oligofructose-enriched inulin prevented the increase in inner-colonic mucus penetrability. Mucus growth was not restored [3]. The microbial effector was not isolated, and combining the fibre with Bifidobacterium longum NCC2705 did not preserve the penetrability effect [3]. That is a defined mouse exposure of the enriched mixture. It is not an indispensable nutrient, not a human dose, and not a result for inulin alone or for oligofructose alone [1,3].

## Dietary Origin

Chicory and some other plants store inulin-type fructans across a range of chain lengths. A food that contains mixed fructans does not, by that fact, contain a standardised long-chain inulin ingredient or the enriched blend used in the mouse diet [1]. Commercial oligofructose is usually a partial hydrolysate of chicory inulin and is a different preparation [1,2].

The edible spear of green asparagus has one verified inulin record: 1.30 g per 100 g dry matter, from a hot-water extract of lyophilized spear, with DP3 and DP4 oligosaccharides absent from that spear. Root inulin is not that record, and the dry-matter figure is not a fresh-weight serving. Chicory root, Jerusalem artichoke, onion, garlic and leek do not yet have a measurement that separates longer-chain inulin from short-chain oligofructose, so they are not linked here.

## Research Spotlights & Evidence Checks

<EvidencePresentation
  kind="check"
  title="Does the mouse mucus result belong to inulin alone?"
  exposureContext="isolated-substance"
  summary="No. The preparation was oligofructose-enriched inulin. Mucus growth was not restored, and adding a named Bifidobacterium strain did not preserve the penetrability effect [3]."
>

The mouse study prevented increased inner-colonic mucus penetrability on a Western diet [3]. The material was the enriched blend, which Roberfroid separates from both longer-chain inulin and short-chain oligofructose [1]. The result cannot be reassigned to either fraction alone, or to a serving of chicory, onion, or garlic [1,3].

</EvidencePresentation>

## Recipes

<SubstanceRecipes tag="Inulin" />

## Foods

<SubstanceFoods tag="Inulin" />

## Biological Regulatory Systems

| Biological Regulatory System | Evidence-qualified relationship | Evidence |
| --- | --- | --- |
| [Gut-Brain Axis & Enteric Nervous System](/docs/biological-targets/gut-brain-axis-enteric-nervous-system) (BRS5) | Oligofructose-enriched inulin, not inulin alone, is the exposure mapped to [keystone taxa support](/docs/biological-targets/brs5/fm1/brs5-fm1-pm3-keystone-taxa-support). It prevented a Western-diet increase in mouse colonic mucus penetrability and did not restore mucus growth. | [1,3] |

## References

[1] Roberfroid (2007). [Inulin-type fructans: functional food ingredients](/docs/papers/BRAIN-Diet-References#roberfroid_inulin_type_fructans_2007). Separates longer-chain inulin, short-chain oligofructose, and oligofructose-enriched inulin. The mouse result below used the enriched blend.

[2] Niness (1999). [Inulin and oligofructose: what are they?](/docs/papers/BRAIN-Diet-References#niness_inulin_oligofructose_1999). Describes oligofructose as the short-chain subgroup of inulin, with an upper bound of 10 rather than 8, so the cutoff is a convention.

[3] Schroeder et al. (2018). [Bifidobacteria or Fiber Protects against Diet-Induced Microbiota-Mediated Colonic Mucus Deterioration](/docs/papers/BRAIN-Diet-References#schroeder_bifidobacteria_2018). In Western-diet mice, oligofructose-enriched inulin prevented increased inner-colonic mucus penetrability. Mucus growth was not restored, and combining it with B. longum NCC2705 did not preserve the penetrability effect.

## Oligofructose-enriched inulin {#oligofructose-enriched-inulin-schroeder-2018}

The mixture preserved mucus penetrability in Western-diet mice, not mucus growth. Combining it with NCC2705 did not preserve the penetrability effect; constituent efficacy cannot be inferred. [Original study](/docs/papers/BRAIN-Diet-References#schroeder_bifidobacteria_2018).

This identity denotes the source-specific studied material. Manufacturer, batch, formulation proportions and analytical specifications must not be inferred from its name; details not established in the retained record remain unspecified. Sharing this documentation page does not make the material equivalent to the parent substance or its ordinary food sources.
