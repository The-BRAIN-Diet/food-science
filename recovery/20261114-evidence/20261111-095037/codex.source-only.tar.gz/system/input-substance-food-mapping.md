# Input to Substance to Food

Status: BRS1 inventory and four-PM UI pilot. Generated joins; no new scientific admission, composition registry or food quantity target.

## Authority and outputs

- PM records: `dietary_input_traceability`, `dietary_lever_atoms`, structured presentations in §1.1.1–1.1.3 / §3.1.1–3.1.3. PM-to-KC relationships preserve independently admitted PM atom IDs, KC constituent IDs and accepted scope.
- Dependencies: read external PM/KC documents only through explicit BRS1 relationships. This pilot reads BRS2 PM7 and BRS2 KC1, not other BRS scientific inventories.
- Identity: `registry/substances.json` plus canonical page titles/IDs and documented synonyms. Never use taxonomy to infer PM admission or food presence.
- Foods: canonical `substance_relationships` and exact-food `nutrition_per_100g`/`nutrition_source` observations, plus supported source-specific supplementary records. No rendered-text extraction, 10% filter, estimate promotion, combined-analyte split or conversion yield.
- Generator: `scripts/lib/input-substance-food.mjs`. Shared preview selection: `src/data/inputSubstanceFoodSelection.mjs`. CLI exports and Docusaurus `input-substance-food` plugin consume that same engine.
- Review outputs: `system/generated/brs1-input-substance-food/`. JSON is normalized: relationship, source and row identifiers join independently; its values are reproducible snapshots, not independently editable authority. Markdown and CSV repeat values only for review/export.
- Interactive review: `/docs/system/brs1-input-substance-food` (internal docs enabled). PM UI: `PILOT_PMS`, currently BRS1 PM3, PM6, PM7 and PM12.

## Stable joins and identity gaps

Relationship ID is `PM ID::atom ID`, or the existing PM-KC relationship ID. Food-material ID joins canonical food ID, substance ID, documented material and preparation. Each source observation retains a keyed source-record pointer; no midpoint or universal range is calculated. Substance/food pages retain canonical ownership. Missing substance IDs/pages, inconsistent identities and unverifiable upstream references remain explicit gaps; Cursor can create missing pages after synonym checks.

Canonical food relationships are reciprocal by consuming the same food records in both directions. A new food, substance or PM does not require a second list: add the authoritative source record, then regenerate exports. The live plugin watches source documents/registry changes and rebuilds its derived view. Plugin registration or implementation changes require restarting the dev server. Only representative PMs expose disclosures initially.

## Accounting versus biology

A = PM-owned dietary relationship. B = accepted upstream PM **supply** reference (other upstream links do not erase an independently admitted local role). C = upstream iKC/resource constituent relationship, preserving the existing relationship type and applicability. D = shared-pool/KC reference. E = biochemical/endogenous dependency; food occurrence does not admit a dietary supply route.

The original Direct/Derived classification, relationship layer, claim ceiling and biological role remain stored separately. A local biochemical requirement may have dietary occurrence without becoming a PM dietary requirement. A supported upstream resource constituent does not become a new limiting iKC relationship. Pools deduplicate globally by KC ID and constituents by pool+KC atom; dependent PM connections and independent substance roles remain intact.

One canonical substance amount will be calculated once from recipe ingredients later and associated with every supported role. Pools are not another nutrient. Do not add unlike nutrients, duplicate B6 as PLP supply, multiply requirements by PM count, count precursor conversion without a yield, infer priority from biological reach or claim target coverage without a quantitative target. Conditional balance/competition and timing constraints remain in accepted source records and limitations.

## Quantities and preview UX

Opening Food sources shows up to three quantified sources; Expand food list reveals up to ten in total. The preview selects the largest comparable preparation/basis group deterministically, breaking group-size ties lexically. This is a UX default, not a biological priority. Individual values sort descending within the group; tied values are equal, not precise ordinal ranks. Overlapping ranges prevent precise ranking. Other supported food sources retains qualitative observations and other food states. The full food view uses every eligible relationship, not preview selections.

Preparation or measurement-basis gaps prohibit precise ranking without erasing occurrence. Regulatory minima are not product measurements; the algal-oil specification remains an explicit quantitative-adapter gap. No invented range, recipe serving or dose is provided. Compound-class and meal-composition rules retain non-substance identity; candidate ingredient carbohydrate/protein records are review data, not admitted single-food pattern equivalents.

## Required author checks

Run `npm run mappings:brs1` and `npm run test:input-substance-food`. Check complete structured-input coverage; registry identity and upstream supply joins; no duplicate relationship IDs or supply cycles; unique pool/constituent roll-up; qualitative retention; combined-analyte exclusion; reciprocal food/substance consistency; independent roles; and source-value reproducibility. Keep food-composition confidence separate from PM relationship evidence.


## Sixth atomic field — Dietary input (Stage 2A / Stage 2B)

The PM dietary-context contract is **Input | Input type | Biological role | Evidence source | Limitation | Dietary input**. Store the sixth field on the authoritative `dietary_input_traceability` atom as `dietary_input: true`, `false`, or `null`; render these as **Yes**, **No**, or **Unset — clarification required**. Never copy the decision into a separately editable food registry or lever overlay. `dietary_input_note` and `dietary_input_flags` are review metadata, not additional atomic fields. Missing legacy values remain unset until reviewed.

Stage 2A makes the existing accepted supply decision explicit; Stage 2B projects that same atom without reassessing evidence. Preserve findings, citations, limitations, biological role, relationship classification, ownership and upstream/KC applicability.

- §1.1.1 / §3.1.1 Direct/Derived Dietary Requirements normally receive Yes because section admission establishes dietary applicability. Explicit contradictions must be flagged (`section-supply-contradiction`), leaving the value unset pending resolution rather than silently overriding either record.
- §1.1.2 / §3.1.2 Cofactors and Substrates require individual review of the accepted biological role, supply route and limitation. Intracellular participation alone establishes neither Yes nor No.
- §1.1.3 / §3.1.3 Key Constraints/upstream resource inputs distinguish dietary constituents from the pool or constraint itself. A constituent may receive Yes; a pool reference receives No when no dietary supply relationship is admitted for the pool itself. Constituent decisions remain on their PM atoms, never inherited from KC applicability.
- Ambiguous cases receive `dietary_input: null`, a specific `dietary_input_note` and a clarification flag. Do not default to No.

No means **no dietary supply relationship is admitted for this entry in this PM**. It does not mean the substance is absent from food or biologically unnecessary. Lack of demonstrated benefit from extra intake, dose responsiveness or a universal requirement is not alone a reason to assign No. Dietary input and PM ownership/upstream/accounting designation are independent fields.

```yaml
- atom_id: PM-example-DIT-1
  input: Vitamin B6
  input_type: cofactor precursor
  biological_role: Accepted precursor provision for intracellular PLP
  evidence_source: # retain accepted finding and citation references
    finding_ids: [PM-example-F1]
    citation_keys: [accepted_reference_key]
  evidence_limitation: Retain the accepted limitation verbatim
  dietary_input: true
  dietary_input_note: Accepted dietary precursor route; no conversion yield inferred
```

Generate PM-input substance–food lists only for `dietary_input === true`. Keep No and unset entries visible as biological context; suppress their food lists without removing canonical food composition records. The same substance may have Yes and No entries in different PMs. Generated tables expose the sixth field and source note; retain unresolved rows and gaps. Missing optional food quantities do not suppress an admitted qualitative food relationship. SOPs/lifestyle are outside this PM dietary-input migration.


## Preparation and relationship filters for the BRS1 review index

The initial preparation selection is **All preparations**. Include all eligible verified per-100 g observations with their source-specific preparation and measurement basis. Preserve multiple observations; do not average or merge incompatible states. Mixed preparations/bases and overlapping ranges use alphabetical display, not a precise cross-state ranking. A preparation filter narrows food observations, not scientific admissions. The main preview has at most ten material/preparation sources; do not place quantified cooked or dried records in qualitative sources solely because another state has more records.

Ownership is a PM–input relationship property. Initial independent checkboxes select both **PM-owned dietary relationships** (accepted A relationships with Dietary input Yes) and **Upstream/shared relationships** (accepted B/C dietary supply references plus D pool references). D remains a pool reference, not a nutrient amount. Filter relationships first, then generate all three views and visible relationship/substance/food/pool counts from the selected connections. Each remaining substance and food must have a selected dietary relationship. Neither selected yields empty dietary views. Retain unique constituent amounts regardless of reach.

Display each relationship’s designation beside its PM/section connection. Do not label a substance globally as owned or upstream. No/unset biological context remains in a separate disclosure independent of these checkboxes. Dietary Yes with an incompatible/missing accounting designation is explicitly unresolved there; do not infer a category. Search applies within the projected view and reports matching rows separately from relationship-selection totals.


## Scoped generator runs

Run `npm run mappings:brs1` or `npm run mappings:brs2`. Outputs are reproducible under `system/generated/<brs>-input-substance-food/`. Each run reads PM admissions from that BRS and only explicit external dependencies. Missing `dietary_input` values remain unset and are reported; a generator run does not perform scientific admission or populate supply decisions by inference. BRS2 generation does not enable PM food disclosures or publish a new review route.


The review has a single-selection BRS 1–6 button group, initially BRS1. Switching BRS resets preparation to All preparations and pagination while retaining relationship checkbox choices. BRS2 consumes the same generated dataset; generated `src/data/brs2InputMapping.generated.json` is a read-only fallback for existing preview sessions until the plugin reloads. Live plugin data takes precedence. Never hand-edit this snapshot; `npm run mappings:brs2` refreshes it. BRS3–6 display not-generated status without borrowing BRS1 data or implying no scientific relationships exist. Unset dietary flags remain visible as inventory/context, not admitted food supplies.


BRS3–6 generator commands are `npm run mappings:brs3` through `npm run mappings:brs6`; they refresh the corresponding review snapshots and selector datasets exactly as for BRS2. Generation preserves unset dietary decisions, missing projections and conflicting canonical identities. Counts report admitted structured relationships only; narrative-only and unprojected records are explicit coverage gaps, not invented food mappings.


Pending dietary decisions and biological context use the same four substance-review columns as admitted mappings across BRS1–6: Section ID / relationship accounting, Substance, Up to ten quantified sources, and Other supported sources. Group context by canonical substance identity, retaining all PM relationships and accepted limitations. Unknown identities remain explicit inputs. Auto-open this separate context table when the selected main view has no rows, so an incomplete migration does not look like an empty inventory. Unset/No/ambiguous accounting still never admits food supplies, and dietary filters continue to affect only resolved admitted relationships.


For independently admitted food-related SOPs, follow `system/food-strategy-rollup-schema.md`. Record stable `food_strategy_id` and explicit `food_strategy_scope` on the PM SOP atom, retain its original role/evidence/limitation, and regenerate the rollup. A dietary-input No does not admit an SOP. The food rollup is a separate strategy/intervention view; canonical food or substance links require accepted identities and must not be guessed.

### Combined BRS review

The “Show All BRS” selector combines BRS1–6 authoritative projections. Keep every distinct PM–input relationship, while deduplicating substance IDs, food/material source IDs and pool IDs across scopes. Apply the same preparation and relationship filters to the combined data before computing visible counts and connections. Individual BRS selection remains available.


### Canonical compact PM food disclosures

For §1.1.1–1.1.3 and their §3.1.1–3.1.3 aliases, use the original shared plant/animal disclosure presentation: the closed summary contains the group label and first food line (linked food, supported quantity/basis, then preparation; for example `Nutritional Yeast 120 mg per 100 g - dried`). Expanded subsequent food lines align with the first food name using the existing responsive stylesheet. Do not repeat the first observation in the expanded list. Distinct measured preparations remain distinct.

Keep composition-source links, analytical narratives and nested provenance controls off these compact food lines; retain authoritative evidence on the linked food pages and in existing audit records. Do not erase source data or suppress provisional information icons and precise coverage warnings. Do not infer quantities, preparation states or intervention efficacy to simplify presentation.

Food-specific mapping warnings belong inside the corresponding Plant-based or Animal-based food disclosure, under **Food-source mapping notes**, with the information icon beside the exact provisional food row. They must not be inserted into the substance's reader description, Biological role or other six-atom fields. Preserve input-level identity/conversion warnings separately. Use the existing generated food-target records; relocation does not resolve a mapping, change an admission or discard its provenance.


### Approved food-column implementation — 26 October 2026

Canonical order: **category → food → quantity/unit/basis → form**. Use the shared `renderCompactFoodSourceItem`, `renderFoodSourceSummary` and `createFoodSourceDetails` in `src/lib/pmInputFoodDisclosure.ts` for both dietary targets and cofactor/KC disclosures. The first food stays visible in the summary; subsequent observations use the identical column widths. Preserve provisional icons and coverage warnings. Missing form displays exactly **form not known**; this is a presentation fallback, not a recorded preparation or scientific conclusion.

**Unknown food values — owner wording correction, 27 October 2026:** In food-mapping amount columns and dropdown rows, render exactly **value not known** when a verified quantity is unavailable, replacing the former **quantity not established** display. Apply the same fallback in generated mapping displays and mapping review tables. Do not invent zero, attach a per-100 g basis to an unmeasured value, or change the underlying qualitative presence status, measurement, verification decision or source evidence. Numeric values, units, measured bases and the agreed column alignment remain unchanged.

The canonical stylesheet (`src/css/custom.css`) uses:

```css
.pm-input-food-sources {
  --food-label-width: 8.5rem;
  --food-amount-width: 9.75rem;
  --food-name-width: 8.5rem;
  --food-preparation-width: 7rem;
}
.pm-input-food-sources > summary {
  display: grid;
  grid-template-columns: 1.1em var(--food-label-width) minmax(0, 1fr);
  width: 100%;
  align-items: baseline;
}
.pm-input-food-row {
  display: grid;
  grid-template-columns: minmax(0, var(--food-name-width)) var(--food-amount-width) minmax(0, 1fr);
  column-gap: 0.35rem;
  align-items: baseline;
  min-width: 0;
}
.pm-input-food-row > span { min-width: 0; overflow-wrap: anywhere; }
.pm-input-food-name a { color: var(--ifm-link-color); }
.pm-input-food-amount--standard {
  display: grid;
  grid-template-columns: 5ch 2.5ch auto;
  column-gap: 0.35ch;
  font-variant-numeric: tabular-nums;
}
.pm-input-food-number { text-align: right; }
.pm-input-food-basis { white-space: nowrap; }
.pm-input-food-preparation { margin-left: 0; position: relative; left: -2ch; }

.pm-input-food-sources ul,
.pm-input-food-sources[data-food-source-kind="animal-based"] ul {
  display: grid;
  gap: 0.2rem;
  margin: 0.25rem 0 0.35rem calc(1.1em + var(--food-label-width));
  padding: 0;
  list-style: none;
}
.pm-input-food-sources li { margin: 0; }
.pm-input-food-qualification {
  margin: 0.35rem 0 0.25rem;
  color: var(--ifm-color-emphasis-700);
  font-size: 0.86rem;
}
@media (max-width: 600px) {
  .pm-input-food-sources > summary {
    grid-template-columns: 1.1em minmax(0, 1fr);
  }
  .pm-input-food-sources > summary > .pm-input-food-row {
    grid-column: 2;
  }
  .pm-input-food-row {
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  }
  .pm-input-food-preparation { grid-column: 2; }
  .pm-input-food-sources ul,
  .pm-input-food-sources[data-food-source-kind="animal-based"] ul {
    margin-left: 1.1em;
  }
}
```

Quantity parsing in the renderer is deliberately bounded:

```ts
const amount = formatFoodAmount(source);
const standard = amount.match(/^(.+?) (µg|μg|mg|g|kg|IU|kcal) per 100 g$/);
```

For a matching amount, emit separate `.pm-input-food-number`, `.pm-input-food-unit` and `.pm-input-food-basis` spans within `.pm-input-food-amount--standard`. For other bases, retain the complete qualified amount without converting it to per-100-g. Never substitute literal leading spaces: alignment comes from grid columns and tabular numerals.

Long food names wrap within the food column (for example White/Button Mushroom); they must not overlap quantity cells. The expanded list starts at `calc(1.1em + var(--food-label-width))`, identically for both categories. Below 600px, the food row moves under the category label, uses two flexible columns, and form occupies column 2; expanded rows start at `1.1em`. Keep original measurements and qualifications in authoritative records and linked food/audit pages.

Validation: run `node --test scripts/dietary-lever-traceability.test.mjs scripts/input-substance-food.test.mjs`, then interact with a real canonical PM disclosure. Verify both categories and expanded rows share column positions, first-food preview, long-name wrapping, source-specific bases and provisional warnings. Do not regenerate scientific records or dietary outputs to change this presentation.

#### Exact compact row renderer

```ts
function renderCompactFoodSourceItem(source: any): string {
    // Align comparable quantities without rewriting non-standard measurement bases.
    const amount = formatFoodAmount(source);
    const standard = amount.match(/^(.+?) (µg|μg|mg|g|kg|IU|kcal) per 100 g$/);
    const quantity = standard
        ? `<span class="pm-input-food-number">${standard[1]}</span> <span class="pm-input-food-unit">${standard[2]}</span> <span class="pm-input-food-basis">per 100 g</span>`
        : amount;
    return `<span class="pm-input-food-row"><span class="pm-input-food-name"><a href="${esc(source.food_page)}">${esc(source.food_title)}</a></span><span class="pm-input-food-source-meta pm-input-food-amount${standard ? ' pm-input-food-amount--standard' : ''}"> ${quantity}</span><span class="pm-input-food-source-meta pm-input-food-preparation"> - ${formatFoodPrep(source)}</span></span>`;
}
```


Category labels use the same fixed width so their trailing hyphens align, with separation before the first food:

```css
.pm-input-food-source-kind {
  display: inline-block;
  width: var(--food-label-width, 8.5rem);
  text-align-last: justify;
  box-sizing: border-box;
  padding-right: calc(0.5rem + 1ch);
}
```

Food names shift one character left within their grid cell; quantity and form column positions remain unchanged:

```css
.pm-input-food-name { position: relative; left: -1ch; }
```

Quantity cells (value, unit and measurement basis together) shift two characters left without changing their internal alignment or the food column:

```css
.pm-input-food-amount { position: relative; left: -2ch; }
```

Preparation/form cells, including the separator (for example `- dried`), also shift two characters left to follow the quantity column:

```css
.pm-input-food-preparation { margin-left: 0; position: relative; left: -2ch; }
```


### Framework-wide presentation scope — approved 26 October 2026

The approved compact food grid applies to all canonical PMs across BRS1–BRS6 through the shared `PmDietaryLeverEnhancer` and `attachInputFoodDisclosure`, including canonical section aliases §1.1.1–1.1.3 / §3.1.1–3.1.3. It is not restricted to the BRS3 PM4 visual acceptance example or the historical four-PM pilot. Reuse available authoritative structured mappings; do not manufacture food rows for pages without eligible mappings or admissions.

Final offsets: category hyphens share a fixed right edge with `padding-right: calc(0.5rem + 1ch)`; food names shift `left: -1ch`; the complete amount and preparation cells both shift `left: -2ch`. Preserve aligned values, units and measurement bases, wrapped long food names, first-food previews, provisional icons and warnings. No per-PM scientific migration is required to receive the shared stylesheet.

## Shared ranked PM/Food Wheel selection — approved preview, 9 November 2026

For ranked PM dietary food disclosures and the Food Wheel, the shared generated target snapshot supersedes the earlier per-category preview selection above. `scripts/generate-ranked-food-sources.mjs` consumes publication-approved canonical sources and `src/data/rankedFoodSources.mjs`; both consumers use the exact selected observations, ranks, powers and limitations. Select up to ten globally before plant/animal grouping, Relative Source Power ≥10% (provisional), and at least two genuinely comparable independent food sources. Preserve chemical forms, edible-versus-dry-weight denominators and documented preparations. Ordinary edible preparations may compete; explicit dry powder describes the preparation, not a dry-weight denominator.

The following two-layer correction supersedes the earlier prohibition on a separate unranked-food list. Canonical occurrence records and necessary existing scientific qualifications remain intact. Explicit target-specific non-rankable restrictions and composition holds are in `system/ranked-food-source-policy.json`; they do not change scientific admissions. Reused generic panels cannot count twice: the source-matching cocoa panel is attributed once; the olive-oil proxy remains held under the exact-food contract. Independent supplementary records retain their own qualifications. The approved lupin alias resolves to `lupins` once.

Scope: shared top-ten preview authorised by the owner, with cocoa attribution and retained oil hold confirmed on 9 November 2026. No production approval. See `review/food-wheel-top-ten-2026-11-09/TOP-TEN-COVERAGE-RECONCILIATION.md`. Do not import unpublished scientific backfills merely to reproduce older wheel coverage.


### PM documented-occurrence layer — author-approved correction, 9 November 2026

The shared top-ten/10% contract governs quantitative ranking, not all PM source visibility. PMs retain the unchanged shared ranked sources, followed by an existing-style disclosure titled **Documented, unranked sources** for canonical, evidence-qualified qualitative occurrences connected to existing admitted dietary inputs. Label these **Quantity not established — not ranked**. Preserve the original food identity, preparation, chemical form, delivery limitations and references. No RSP, numeric rank, inferred quantity or wheel-count contribution is assigned.

Use reconciled PM food targets when supplied; an empty target list must not be repopulated from unrelated global sources. Require supported occurrence and source provenance. Respect record-level public-display exclusions and publication holds; an independently public canonical contains relationship may remain visible while an internal-only supplementary annotation remains hidden. Do not turn held quantitative observations, candidate mappings or biochemical participants into qualitative dietary admissions. Deduplicate ranked versus unranked food/substance pairs while retaining distinct material/form qualifications within the unranked layer.

Food grouping uses canonical food identity, not mentions inside analytical prose: trout roe is animal-derived; tahini is plant-derived. This changes neither food composition nor admission. Apply to existing admitted PM dietary inputs across BRS1–6/BRS-X. Representative fixture and counts: `review/pm-food-source-visibility-2026-11-09/`. Author instruction: “Correct PM Food-Source Visibility Regression”. Local implementation only; no build, deployment or PR update until review.


### Approved measured-but-unrankable sources — 9 November 2026
Owner approval: CODEX EXEC — Measured-but-Unrankable Food Presentation. Reuse Documented, unranked sources for 5-MTHF, ellagic acid, inulin and resistant starch. Show original point/range, unit, denominator, preparation, citation and exclusion reason. Separate calculated-from-measurements, measured non-comparable and qualitative occurrence labels. Keep independent studies separate and retain calculation/variability/source qualifications. Verified provisional source-context mappings remain explicitly qualified, not silently upgraded. Preserve all target/source publication and protocol holds. Never recover sources excluded solely by RSP threshold or top-ten cap; rankings remain unchanged. No inferred conversions, range midpoints or downstream quantities. See review/dietary-connectivity-2026-11-09/measured-unranked/REPORT.md.

### Approved Food Wheel evidence-ledger publication — 9 November 2026

The author-approved relationship-specific permissions in `system/food-wheel-evidence-publication.json` permit the five exact experimental child–PM records to be published in the written Food Wheel evidence ledger. The canonical identity and PM atom are resolved at generation time; the frozen ranked network is not the scientific authority for this ledger. This narrowly scoped permission does not release ordinary-food projection holds, infer parent food occurrence, change dietary admissions or permit recipe ingredient edges. Registry-level food/network holds remain the conservative default outside this explicit publication surface.

The ledger separately displays eligible documented-unranked parent occurrences and measurements using the existing PM documented-source selector, and identifies Bifidobacterium growth-support statements as distinct from food occurrence. KC/resource scope must not be relabelled as a Direct dietary admission. The ranked selector remains top ten, provisional ≥10% RSP and at least two comparable foods. No experimental effect or quantity inherits across parent/child identities.
