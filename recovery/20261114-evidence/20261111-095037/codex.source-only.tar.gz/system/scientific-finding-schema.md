# Stage 2A — Scientific Assessment & Finding Schema

**Approved canonical food-disclosure layout — 26 October 2026:** Follow [the exact food-column implementation](input-substance-food-mapping.md#approved-food-column-implementation--26-october-2026). Reuse the shared renderer and stylesheet for §1.1.1–1.1.3 / §3.1.1–3.1.3: first food in the closed heading, food before quantity, fixed shared columns, right-aligned numeric values, aligned units/bases, wrapped long names and compact form. Missing form renders `form not known`; an unavailable verified food-mapping amount renders exactly `value not known` (owner wording correction, 27 October 2026). This display wording does not alter underlying qualitative presence records or imply a zero value. Stage reruns must preserve this layout, evidence qualifiers, provisional warnings and canonical data; do not author replacement food lists or inline composition-source prose. The linked contract includes the CSS, renderer parsing rule and required browser checks. The final approved row reads `Sunflower Seeds 53 µg per 100 g - dried`: food column 8.5rem, quantity column 9.75rem, 0.35rem column gap, right-aligned numbers with tabular numerals, and no manual space padding or negative preparation margin. Use exactly ` - ` before the form; retain source-specific measurement bases. The first food and expanded rows must use the same grid for both plant and animal categories. This presentation is framework-wide across BRS1–BRS6, not a PM4-only pilot; apply it through shared rendering wherever eligible structured food mappings exist.

**Section 4 placement correction — 27 October 2026:** Apply `scientific_findings_placement: section-4` during controlled correction. Retain the visible Summary, canonical mechanism dropdown, boundaries and integration, followed by dynamically counted §4.1 Findings generated from the authoritative records. Evidence & Audit retains Principles, SEC appraisal and history, not duplicate SF disclosures. Preserve current scores, sources, admissions and historical links. PM8 is the corrected pilot; do not migrate unrelated PMs automatically.

**Exact SF presentation reference — 27 October 2026:** Follow the [PM1 Section 4 reference layout](pm-evidence-tabs-contract.md#pm1-section-4-reference-layout--one-dropdown-per-finding). Every active mechanism Finding has its own sibling `ScientificFinding` dropdown under §4.1, outside the mechanistic-detail dropdown. Preserve its short SF title, compact SEC/audit line, own summary and interpretation, nested Explore the evidence and individual-study assessments, and reciprocal mechanism link. Stage 2A supplies one canonical record per proposition; neither a shared parent dropdown nor an audit-only link substitutes for the individual SF disclosures. This is a presentation contract, not a new assessment or confidence scale.

**Approved canonical evidence-tab template — 26 October 2026:** Follow [Canonical PM evidence tabs](pm-evidence-tabs-contract.md). The accepted PM8 template governs Stage 2A/2B and subsequent controlled PM migrations: Evidence Gaps → Open Issues → Evidence & Audit, with canonical disclosures and stable IDs. This instruction update does not itself migrate other PMs or change scientific decisions.

**Approved governance revision — 23 October 2026:** [Dietary input admission and food target traceability](dietary-input-governance-v2.md) governs new/changed dietary assessments, section eligibility, independent Type A/B admission, food-target research, provisional display and repair reporting. Historical decisions remain traceable; this revision does not reapprove or migrate them. The six atoms and CC/SEC scoring remain unchanged.

**Status:** Authoritative Stage 2A scientific assessment instruction and Finding schema. Use with the [whole-PM page schema](primary-mechanism-schema.md); proceed to the [Stage 2B contract](dietary-input-traceability-contract.md) for applicability and lever implementation.

The canonical evidence unit for mechanism pages. A Scientific Finding states a
proposition precise enough to be assessed across a body of evidence, and carries
the synthesis, the limits of that synthesis, and every study considered.

Replaces the earlier pattern of *mechanistic claim → one or more references*.

## Evidence classification and tab handoff — mandatory before SEC

Apply [Canonical PM evidence tabs](pm-evidence-tabs-contract.md) before scoring or generating public evidence presentation.

1. Identify each exact proposition and its scientific role. Separate established biochemical identities/reactions (**Scientific Principles**) from appraisable regulatory, physiological, dietary or functional propositions (**Scientific Findings**). Preclinical research can require SEC; being biochemical, weak or unscored does not qualify it as a Principle. Split mixed propositions only where their scientific content warrants it, retaining historical identities and provenance.
2. Identify what the evidence establishes and what it cannot establish. When a required link to a proposed active claim is missing, inconsistent or indirect, record an **Evidence Gap** with canonical Finding/source references, the missing link, affected relationship and evidence needed. Do not copy source assessments into a second evidence dataset or relocate valid mechanism explanation merely because no dietary benefit is established.
3. Identify genuinely unresolved decisions as **Open Issues** in the authoritative register, with a resolution criterion. Do not recreate resolved questions, generate issues from unscored SEC alone, or use a completed non-admission as an artificial active issue. Respect owner-approved removal and PM-specific regeneration policies.
4. Hand off an explicit disposition and destination for each record: necessary accepted mechanism explanation and **Scientific Findings in §4.1**, with Summary → mechanism → Finding mapping and reciprocal links; Principles, SEC assessments, provenance and history in **Evidence & Audit**, without duplicate Finding disclosures; missing evidential relationships in **Evidence Gaps**; actionable unresolved decisions in **Open Issues**. A study may support multiple bounded purposes through references to one canonical evidence record.
5. Apply existing SEC governance only to the adjudicated Finding proposition. Principles expose authoritative provenance without an active SEC score/status/factor display. Preserve active Findings, original IDs, historical assessments and essential qualifications. Do not reclassify evidence to improve numerical scoring coverage.

The Stage 2B handoff must identify any proposed scientific change requiring approval separately from presentation-only relocation. No admission, Type A/B, Direct/Derived, KC or intervention decision changes merely because evidence moves tabs.

## Bounded assessment

### Source interpretation boundaries

Identify primary experiment versus secondary synthesis explicitly in existing
study/design, result, limitations and retrieval fields, independently of data
level. A review of cellular experiments is secondary synthesis, not another
primary cellular replication. Do not count an underlying study and its review
as independent experiments.

Where material to the claim, record anatomical compartment, observation window,
measured endpoint, inference/model status and tracer origin. Concentration is
not production flux; separately infused product tracing is not automatically
evidence of precursor conversion. A null in one compartment does not establish
absence of a process elsewhere. Preserve the distinction between measured
substrate utilisation, measured product concentrations and inferred production.
Synchronise repeated source assessments and generated presentation after a
correction. These clarifications add no disclosure atom or scoring rule.

**The ontology proposes the question. Evidence gets to challenge it.**

KC-page review uses this same bounded-assessment order on KC title, iKC,
constituent, and proposed-scope propositions (`system/kc-page-evidence-review-contract.md`).
Durable KC records remain `kc_input_traceability`; do not require PM-scoped
`PMn-F*` Finding ids on KC pages.

PM evidence assessment is not an exhaustive literature review. **Review existing
evidence first does not mean stop with existing evidence.** Work in this order:

1. **Define the proposition** — from the intended scope in Mission, every
   substantive claim in Overview, the **existing** Mechanistic Basis
   (biological propositions), published PM connections, and any **defining
   mission or pathway step** those sections omit. The Mission states the scope
   to assess; it is not evidence that the mechanism achieves that objective.
   Mechanistic Basis is the **starting** boundary for assessment, not an
   immutable one and not a licence to ignore a central step that was never
   written down.
2. **Assess relevant evidence** — inventory and review **all references already
   attached to the PM page first**, including references used by Findings,
   Phenome relationships and Connected / Supportive Evidence. Test each source
   against the actual proposition; presence on the page does not make it
   relevant or supportive. If that corpus cannot adequately establish a central
   mechanism or relationship, or if complementary or newer evidence could
   materially change the synthesis, conduct **targeted external research**. Do
   not treat corpus-first wording as a stop rule.
3. **Adjudicate** — supported, triangulated, gap, contradicted, **unresolved**,
   or **unassessed**. Those last two are not evidence-supported rejections.
4. **Stop** when each listed proposition, and each identified central
   mission/pathway step, is adjudicated or explicitly parked with an explicit
   question and a stopping rationale. Stopping because the attached
   bibliography ran out is not sufficient when a defining step remains
   unassessed.
5. **If adjudication materially challenges PM scope** — flag a PM-scope consequence
   and review Mission, Overview, and Mechanistic Basis together. See
   `system/primary-mechanism-schema.md` § **PM scope consistency (evidence assessment)**.
   This is a consistency check, not an automatic rewrite and not a return to
   open-ended research.

**Finding triggers:**

- a defined **Mechanistic Basis** proposition under test;
- a defined **PM → Phenome relationship** proposition under test; or
- a **defining mission or pathway step** required to establish the mechanism,
  including a step omitted from the current Mechanistic Basis.

Mechanistic Findings test Mechanistic Basis propositions. Phenome-linked Findings
test relationship propositions. A Finding genuinely relevant to both is authored
once and cross-referenced — never duplicated.

**Not every useful study → new Finding.** Adjacent, contextual, or wrong-construct
evidence belongs in Connected / Supportive Evidence unless it directly answers an
listed unanswered proposition. Do not expand into adjacent literature simply
because it exists. Do not use that sentence to skip targeted retrieval for a
central, still-unestablished step.

### Foundational coverage and targeted retrieval (Stage 2A)

The existing corpus is the starting point, not an automatic stopping point.
Check coverage against the mission, including defining steps omitted from
existing prose.

Stage 2A must:

- check foundational evidence across the stated mission and pathway;
- identify missing steps, unsupported claims and obvious omissions;
- conduct targeted external research where the corpus cannot adequately
  establish a central mechanism or relationship;
- check for relevant complementary or newer evidence where it could materially
  change the synthesis;
- explain, in the Stage 2A report, why the evidence coverage is sufficient
  before declaring completion.

Targeted retrieval is bounded by **explicit questions** and a **stopping
rationale** in the Stage 2A report. Do not require an exhaustive search or an
automatic search for every claim. Cost efficiency comes from targeted retrieval
and reuse of verified evidence, not from omitting necessary assessment.

Keep **unassessed**, **unresolved** and **evidence-supported negative**
decisions distinct. Record unassessed and unresolved items in the Stage 2A
report and, where durable, in `system/mechanism-change-control-queue.md`.

Before declaring Stage 2A complete, the report must explain why evidence
coverage is sufficient and record the bounded-search stopping rationale.
Successful schema validation (`findings:check`, page validators, tests) is
not scientific completion.

### Evidence limitations versus retrieval and assessment limitations

> Evidence-confidence conclusions must distinguish limitations of the underlying scientific evidence from limitations of the framework's evidence retrieval and assessment. Absence of verified evidence within an assessment must not be represented as evidence of absence.

Keep these statements distinct:

- **A. “There is insufficient evidence.”** A statement about the entire scientific literature; it requires a sufficiently comprehensive assessment and cannot follow merely from incomplete searching or inaccessible papers.
- **B. “Insufficient evidence was identified in this assessment.”** A statement about the evidence actually retrieved and evaluated, without claiming that supporting research does not exist elsewhere.
- **C. “Independent replication was not established in this assessment.”** A statement that sufficiently independent replication of the exact proposition has not been verified in this assessment.

Use the existing Stage 2A report to record searches and retrieved evidence, pivotal evidence assessed, inaccessible sources, supporting/contradictory/contextual evidence, whether independent replication was verified, and which uncertainties arise from incomplete retrieval rather than demonstrated scientific weakness. Preserve the exact assessed proposition and bounded-search stopping rationale.

**Unknown is not zero.** In provisional SEC assessment, incomplete replication retrieval does not establish R0; that judgement requires an assessed evidence body meeting the rubric's criteria. Inaccessible methods or uncertainty estimates do not establish B0 or P0. Preserve unresolved factors, avoid unjustified confidence downgrades, and retain Not scored unless all four factor judgements are defensible. This clarification adds no scoring anchors, formula or admission threshold.

### SEC assessment status and provisional completion

Apply the [SEC status distinction and provisional acceptance gate](reviews/sec-calibration/SEC-calibration-rubric-proposal.html#sec-assessment-status). Stage 2A may complete a **Codex-assessed provisional SEC** without human expert approval when the exact proposition, all four defensible factor judgements, proportionate evidence appraisal/recovery, evidence roles, independence, limitations, raw/adjusted totals and caps are documented in an identified, versioned assessment. Exhaustive retrieval or access to every historical paper is not required. A documented limitation does not automatically prohibit a provisional score; an unresolved essential factor does. Keep incomplete assessments **Not scored**, or label a bounded numerical working estimate **Conditional estimate — under calibration**; do not promote conditional factors by arithmetic alone.

**Scientifically reviewed SEC** requires a subsequent recorded qualified human review, including identity, date, outcome, assessed version and changes. Keep SEC confidence level and assessment status separate from existing evidence-review and correction statuses. Record these distinctions in the stage report/versioned audit; this clarification does not expand the canonical `synthesised_evidence_confidence` field beyond its currently authorised value or change admissions, factor anchors, caps or evidence atoms.

### Completion gate — coverage challenge and targeted second search

Before completing either stage, compare the reviewed evidence against the Mission's defining biological steps and relevant intervention candidates. Trigger a second targeted search when a material step or candidate:

- has not been assessed;
- was parked as unresolved without candidate-specific retrieval;
- was excluded using an evidence threshold stricter than the applicability contract; or
- is represented only by indirect endpoints that leave the central question unanswered.

For each triggered question, search relevant pathway, input and endpoint synonyms; follow references from useful primary studies; and seek contradictory or null findings where relevant. Reuse verified sources rather than repeating completed retrieval. Reopen Stage 2A if Stage 2B reveals omitted foundational biology.

Reassess using the permitted evidence-supported chains. Distinguish measured from inferred links, biochemical dependency from dietary applicability, and intervention effects from functional benefit. Do not impose a universal end-to-end human assay or supplementation-efficacy threshold for a biochemical dependency.

Reuse the existing stage report's candidate/evidence/rationale/disposition fields. A concise row must record **coverage gap → targeted question → research examined → revised decision → remaining gap and stopping rationale**. Record actual searches and sources examined, not only a promise to search. Complete only when each material question is adjudicated or explicitly unresolved after targeted review. An exhaustive search or fixed study/Finding count is not required. Structural validation cannot certify scientific adequacy.

### Other intervention routes — mandatory hub coverage and retrieval

For every PM assessment, inspect the parent BRS hub's **System Optimisation Practices** and **Lifestyle Priorities**, together with their definitions in [BRS hub levers schema](brs-hub-levers-schema.md). Review every category for PM-relevant candidates, including categories shown as “Coming soon”; an empty hub category is not evidence of biological irrelevance:

| Hub category | PM assessment boundary |
|---|---|
| Food Preparation & Delivery | Food structure, cooking, bioavailability and nutrient delivery. |
| Conditional Supplementation | Defined, condition-specific supplementation exposures. |
| Dietary & Fasting Protocols | Defined dietary, fasting or timing protocols. |
| Light & Circadian Optimisation | Circadian entrainment and biological timing practices. |
| Stress & Autonomic Regulation | Deliberate autonomic and adaptive-stress interventions. |
| Lifestyle Priorities | Foundational, recurrent behaviours; implemented as canonical §3.3 Lifestyle Levers, distinct from defined §3.2 protocols. |

**Required retrieval trigger:** when canonical §3.1 Dietary Requirements is not the adjudicated principal route, has very low PM-specific intervention relevance, or cannot establish a principal route, actively search primary evidence for plausible PM-specific candidates in the remaining §3.2 and §3.3 groups before completing the assessment. Existing sufficient, verified evidence may be reused with its coverage documented. Lack of a dietary admission does not establish lack of practical intervention routes.

For each hub category, record candidates and evidence decisions, or a mechanism-specific reason that no relevant candidate was identified. Search all categories with plausible PM relevance; do not dismiss a whole group because one candidate failed. Hub entries and “Supports” links propose questions, not automatic PM admissions. Assess the original sources and actual endpoints, context and limitations. Do not populate empty categories, inherit hub claims, or force a principal route merely to complete the frame.

Stage 2A assesses the biological propositions and evidence; Stage 2B adjudicates and implements requirements, practices and lifestyle relationships in their existing categories. Record evidence qualification separately from principal-route selection. Reassess placement after reviewing the relevant groups, without automatically treating supported entries as dominant or inferring equal dominance. If another stage must finish the adjudication, record the handoff and leave the combined assessment incomplete rather than declaring full lever coverage.

**Proportionate intervention-landscape coverage:** Set research breadth across both SOP and lifestyle routes from the PM mission, plausible intervention diversity and the adequacy of existing verified evidence. Search relevant combinations of mission and mechanistic-target terms, intervention types, biological endpoints and functional outcomes. Reuse the canonical hub-category definitions above and in the BRS hub levers schema; the following are discovery prompts, not replacement taxonomies, additional admission categories or mandatory evidence requirements for every PM:

- Dietary and SOP discovery: substrate provision; food selection and sustained dietary patterns; meal composition and macronutrient combinations; preparation, processing and food structure; sequencing, timing and frequency; fermentable substrates and dietary diversity; supplements and isolated compounds; hydration and relevant beverages; and other mechanism-specific optimisation practices.
- Lifestyle discovery: aerobic, resistance and other exercise modalities; acute movement, post-meal activity and sedentary interruption; sleep duration, quality, consistency and hygiene; circadian entrainment, light exposure and behavioural timing; stress management and psychological interventions; breathwork, relaxation and autonomic regulation; environmental exposures and behavioural routines; and other relevant interventions supported by mechanistic or clinical evidence.

Screen every canonical SOP hub category and Lifestyle Priorities for relevance. Within materially relevant categories, investigate the principal intervention families and meaningful alternatives. Do not describe an isolated intervention as representative of an entire family or category without adequate coverage. Where an SOP or eating pattern is a principal practical route, assess the principal plausible families before describing public lever coverage as representative. For a PM primarily concerned with biochemical resource dependencies, a focused intervention assessment may be sufficient. Do not require exhaustive searches in irrelevant categories; document the mechanism-specific screening rationale rather than omitting category screening.

Discovery-list placement does not determine scientific ownership. Preserve existing SOP versus lifestyle classification and intervention-dominance contracts; do not reclassify an intervention because it appears in both prompt lists. Defined light/circadian and autonomic protocols remain SOP candidates, while foundational recurrent behaviours retain their existing lifestyle ownership. Food selection, dietary patterns and preparation do not become lifestyle levers through these prompts. Candidates require existing adjudication; do not create new canonical intervention categories.

Reuse the existing Stage 2A report and candidate/evidence/rationale/disposition fields. Record the rationale for breadth, actual search terms, databases or discovery services and search dates, relevant date restrictions, selection boundaries, categories screened, families searched, supporting and null evidence, remaining gaps and stopping rationale. Reuse sufficient verified evidence. Apply the existing contradictory/null-evidence requirement across material families, considering failed target engagement, population-dependent effects, dose-response uncertainty, feasibility and safety limitations where relevant. Do not count publications from the same cohort as independent replication. These requirements extend existing assessment steps, not a new mandatory research stage.

### Evidence-supported Overview (Stage 2A)

**References stay with this PM.** In Biological Relevance and in every other section, do not cite a study because another PM uses it. A reference may appear on this page only when it supports a claim about this page’s own mechanism. A sentence that only sets a boundary with a neighbouring PM names that PM, for example “see PM2”, and carries no citation.

Every Stage 2A PM review must assess and publish an evidence-supported
`### Overview`. Treat each substantive Overview statement as a proposition
alongside the Mission scope, Mechanistic Basis, defining pathway steps and
Phenome relationships. Do not treat inherited Overview prose as established
merely because it is already published.

**Stage ownership:** Stage 2A assesses and authors the Overview. The PM schema's **PM §1 — Mission & Overview** implements this same rule; prose guidance is supporting authoring guidance, not a separate assessment workflow. Stage 2B adjudicates dietary and other lever candidates. Overview wording must not independently admit a candidate or imply an unassessed intervention is established. When Stage 2B changes an admitted lever or its boundaries, reconcile the affected Overview claims with the Stage 2A evidence.

**Opening paragraph:** Explain the biological job, why it matters for health, and what the evidence measured, including practical support where that support is itself a measured result. Aim for ~65–75 words (acceptable authoring range 50–90), understandable in ~20 seconds. Write an orientation, not a technical study summary. Do not close the paragraph with an outcome ceiling — a statement that extra intake, supplementation, or treatment has not been shown to improve symptoms, attention, mood, or a named condition. When a lever is admitted, state one use condition in Implementation Notes: the form, the meal pattern, or the dose gap. When no lever is admitted, omit Implementation Notes.

**Overview scope:** State relevance for cognitive function and brain health. Do not name ADHD or another therapeutic area in the paragraph or the bullets. Do not mention medication. Medication is outside this framework. Condition-specific and medication evidence belongs on Therapeutic Area pages and, where a Phenome relationship requires the studied population, in §7.

**Preferred bullets, in order:**

1. **Benefits:** say what useful function is preserved when this process is adequately maintained. The rule is set out under **Benefits** below.
2. **Implementation Notes:** open with the admitted lever’s name, using the same label as Dietary Requirements, then the one use condition: form, preparation, meal pattern, or dose gap. Link to the disclosure where useful. Where no lever is admitted, omit this bullet. Do not add a bullet whose only content is that no regimen exists, and do not invent a dose, food advice, or broader ingredient effect.
3. **Biological Relevance:** name the one mix-up a nutritionist is likely to make: a neighbouring mechanism, a measurement that is not this job, or a nutrient reading that does not follow. One sentence. When the sentence only marks a neighbouring PM as outside this job, end with a pointer such as “see PM2” and do not cite that PM’s papers. Omit the bullet when the paragraph or another bullet already makes that mix-up clear.

**Benefits:** Write for a nutritionist or an informed reader. Ask what useful biological, physiological, cognitive, or everyday function this process helps preserve when it is adequately maintained. That is the value of keeping the process. It is not a claim that eating more of a listed nutrient will improve the function.

Use one to three sentences:

1. Name the function this PM regulates, supplies, or enables.
2. Say why keeping that function matters, at the highest level the page’s existing evidence supports: cellular, tissue, physiological, cognitive, or everyday. If the evidence reaches only a cellular or physiological function, stop there. Do not invent a clinical, cognitive, or everyday outcome to make the benefit sound more concrete.
3. Add a boundary only where a reader could take biological necessity as evidence that more intake produces a benefit. Say what the cited evidence does not establish about diet, supplementation, symptoms, disease, or clinical benefit. Do not put that disclaimer on every page, and do not put an outcome ceiling in the opening paragraph.

Neighbouring PMs must name their own contribution. Remethylation restores methionine. SAMe synthesis supplies the shared methyl donor. Methionine-cycle flux coordinates the competing demands. Transsulfuration directs sulfur toward cysteine. Glutathione synthesis supplies the antioxidant thiol.

Use **supports**, **helps maintain**, **contributes to**, **enables**, **supplies**, **coordinates**, or **helps protect**. Do not use **improves**, **enhances**, **prevents**, **treats**, or **reduces symptoms** unless the cited evidence establishes that outcome. Do not turn a requirement into a supplementation recommendation, and do not imply that more pathway activity, neurotransmitter, nutrient, or substrate is better. Keep nonlinear, baseline-dependent, region-specific, and population-specific qualifications. Separate the value of maintaining the process from the effect of a dietary or lifestyle intervention.

Cite each extended claim beside the sentence it supports, using a source already on the page that actually supports it. If the references support only the mechanism, call the further point biological or functional relevance, not a measured health outcome. Do not infer a downstream outcome from the PM title. If the further point cannot be supported, keep the narrower biological benefit and record the citation gap in the Stage 2A report. Revising Benefits does not change evidence classifications, dietary requirements, intervention mappings, or any other section.

A nutritionist who reads only this bullet should be able to say what function is maintained, why that matters, whether the wording is a biological requirement, a functional relevance, an observed outcome, or an intervention effect, and whether it stays inside the cited evidence.

**Adaptation:** These are preferred roles, not an exact three-bullet quota. Omit, combine or substitute a role when sufficiently relevant supported points are unavailable, and record a concise rationale in the Stage 2A report. A page with no admitted lever omits Implementation Notes. Do not pad, repeat the paragraph, or manufacture a benefit, action, or “no regimen” bullet to reach three.

**Placement:** Put detailed mechanism inclusion/exclusion boundaries, endpoint distinctions and study limitations in §4 Mechanistic Basis / Scientific Findings. Retain an essential practical claim boundary beside an implementation suggestion where necessary. The Overview must accurately reflect scope without becoming a boundary checklist. Preserve the governing Mission → Intervention Dominance → adjudicated principal groups → Overview order; do not duplicate lever groups.

**Evidence reuse — purpose and scope included:** Substantiate the Mission, purpose, scope, Overview paragraph and bullets from existing adjudicated Findings, study assessments and canonical bibliography. Record each substantive proposition's supporting Finding/source in the Stage 2A report, using a concise table where sufficient. Preserve population, context, measured endpoint and claim ceiling; introductory wording is not exempt from evidence assessment. Use claim-local numbered PM bibliography citations in explanatory prose. The concise Mission may retain its evidence trace in the report instead of an inline citation. Narrow or qualify unsupported propositions, record the exact gap and retrieve targeted evidence only where necessary; do not repeat sufficient verified research solely for the Overview.

Do not attach one general reference to a paragraph containing several claims
that the source does not support. Place each citation beside the claim or
sentence it supports. Reuse already verified evidence where it adequately
answers the proposition; conduct question-bounded retrieval when a material
Overview claim lacks sufficient evidence.

Write for interested members of the public, with nutritionists as the most
technically specialised intended readers. Keep the Overview concise and
explanatory. Study design, effect sizes and detailed limitations remain in the
Scientific Finding disclosures rather than being copied into the introduction.

Before declaring Stage 2A complete:

1. compare the Overview claim by claim with the Scientific Findings;
2. confirm every substantive citation resolves to the intended PM bibliography
   reference;
3. inspect the rendered introduction and confirm it communicates the assessed
   science and boundaries clearly; and
4. record the Overview check and any unresolved claim in the Stage 2A report.

This requirement applies to future Stage 2A runs and to a PM whenever its Stage
2A assessment is reopened. Existing uncited Overviews are a legacy review
queue, not authority to bulk-rewrite every PM without assessment. Record them
for later review and correct them through the relevant PM's Stage 2A pass.

### Retrieval authorisation (supersedes earlier session limits)

The earlier session rule requiring a **separate request** before external
research is **superseded** for Stage 2A and Stage 2B. Running either stage
authorises necessary, question-bounded evidence retrieval under its
contract. Cost concerns should guide efficient retrieval and reuse, not
omission of material assessment. Prior chat instructions, “no open
literature search” report lines, and session conventions do not restore
the old limit.

### Stage boundary — 2A mechanism, 2B diet

Stage 2A establishes the scientific mechanism: defining pathway steps,
reaction participants, regulation, functional evidence and
connected-mechanism dependencies. It identifies candidates for dietary
assessment without admitting them as Dietary Requirements.

Stage 2B adjudicates dietary relationships: provision of substrates and
cofactors, derived dietary routes and state-regulation inputs. It uses
Stage 2A Findings and retrieves further evidence where needed.

For nutritional capacity relationships, Stage 2B applies the B/D
dependency-supply model: B establishes the PM biological dependency; D establishes
the dietary pathway that supplies or maintains that same dependency pathway.
Capacity Dietary Requirement = B AND D. B and D are adjudication propositions
recorded in the existing Stage 2B review; they are not new Scientific Finding
fields, disclosure atoms or a parallel schema. Biochemical necessity, dietary
provision, demonstrated modulation and functional or clinical benefit remain
separate claims.

If Stage 2B discovers a missing foundational mechanism claim, record and
route that gap back to Stage 2A. Do not silently bypass the Finding
assessment. The focused follow-up path is defined in
`system/dietary-input-traceability-contract.md` § **When Stage 2B
identifies a missing foundational claim**.

Do not write PM-specific exceptions into this boundary.

### Claim thresholds

**Biochemical necessity**, **dietary provision**, **demonstrated
modulation** and **functional or clinical benefit** are distinct claims.
Do not require clinical benefit to establish a supported dependency, or
infer modulation from dependency alone.

**Functional translation:** For both SOP and lifestyle candidates, distinguish biochemical or molecular target engagement, physiological effects, functional or behavioural outcomes, and clinical outcomes. These describe claim scope, not a new evidence score or admission hierarchy. Where neurologically relevant, investigate measured attention, cognitive energy, fatigue, executive function, emotional regulation, sleep/arousal or other canonical phenome outcomes. Record relevant ADHD evidence or its absence without requiring direct ADHD or cognitive outcomes to establish a supported biochemical dependency. Do not infer functional or clinical benefit from a biological endpoint alone.

For principal intervention evidence, retain design and sample size, population and baseline health or metabolic status, exact intervention and comparator, dose/intensity, exposure duration and timing, endpoint and measurement method, effect estimate and uncertainty where available, null findings, safety limitations and generalisation limits. State whether biological and functional outcomes were measured together, whether their relationship was tested, and whether the evidence supports an intervention effect, association or an inferred link. Joint metabolic and cognitive measurement alone does not establish mediation. Do not transfer results automatically between clinical, metabolically impaired, healthy or ADHD populations. Use the existing phenome review process for candidate mappings; this assessment does not assign final phenome confidence or confer scientific admission.

**Research hypotheses:** An unresolved but biologically supported question may be recorded as a labelled research hypothesis in the Stage 2A report. Identify its rationale, supporting and conflicting evidence, unverified causal steps, testable prediction, relevant outcome, major confounders and evidence needed for adjudication. A hypothesis does not admit a Dietary Requirement, SOP, lifestyle lever, KC relationship or phenome benefit. Preserve Stage 2B admission thresholds and six-atom governance; neither functional outcomes nor hypotheses bypass existing adjudication.

**Eating-pattern translation:** Where supported, identify the intervention's implications for food selection, combinations, preparation, sequencing, timing, frequency or sustained exposure. Separate evidence for the intervention from evidence supporting a particular food or meal implementation. Reuse the [food-strategy roll-up](food-strategy-rollup-schema.md) and [food-nutrition](food-nutrition-schema.md) contracts; preserve studied materials, protocols and limitations. Nutrient composition, food membership or food tags alone do not establish meal-level rules. Record missing translation data separately from unresolved scientific evidence.

## PM scope triangulation (headline Finding promotion)

Scientific validity is **necessary but not sufficient** for headline Primary
Mechanism Finding status.

Before promoting candidate evidence to a headline PM Finding (`PMn-Fm`), test:

1. **Mission** — Does it directly address the PM Mission?
2. **Overview** — Does it materially establish, refine, or challenge the PM Overview?
3. **Mechanism capacity** — Does it establish a biological requirement, determinant,
   capacity, or important mechanism-level constraint represented by this PM?
4. **Interpretive role** — Is its primary purpose instead to interpret another
   evidence type (e.g. concentration versus flux)?
5. **Scope drift** — Would promoting it cause the PM to drift into adjacent biology,
   measurement methodology, or general literature review?

If (4) or (5) apply without sufficient support from (1)–(3), **do not** promote to a
headline PM Finding. Represent it as Connected / Supportive / Interpretive Evidence.
If evidence genuinely shows Mission or Overview are too narrow or wrong, **raise Change
Control** — do not silently widen the PM.

This is **not** a dietary filter: non-dietary biology may qualify when it materially
establishes the mechanism in Mission + Overview.

**Worked precedent:** BRS1-FM4-PM9 — concentration-versus-synthesis is scientifically
valid but demoted to `PM9-IC1` (`interpretive-constraint`) because it constrains how
other evidence is read, not GAD-dependent synthesis capacity itself. It does **not**
render in §4.1 or as a Finding card in §5. Its scientific consequences belong in the
relevant Phenome **Rationale**, with numbered citations to the underlying studies
(Mason, Manor), not to the IC id.

**Presentation vs ownership:** Relationship Findings may be shown as supporting
evidence in §5. Interpretive constraints govern interpretation; they are not supporting
Findings. **Evidence ownership does not imply presentation.**

**PM9 §7 Phenome Connections — frozen (production exemplar):** Panel hierarchy
(strength → evidence confidence → Rationale → Supporting evidence), Rationale role,
primary-phenome-only Supporting Evidence, IC synthesis via Rationale + `{{cite:}}` (not
reader-facing IC cards), and numbered PM references are **accepted**. Change only via
concrete defect or Change Control — not opportunistic optimisation.

```
MISSION + OVERVIEW
        ↓
BOUNDED PM BIOLOGICAL AMBITION
        ↓
CANDIDATE FINDING
        ↓
Does it materially establish / refine / challenge this PM?
        ↓
YES → PMn-Fm headline Finding
NO, but scientifically useful → Supporting / Connected / Interpretive Evidence
PM scope itself challenged → Change Control
```

## Finding identity and numbering

Headline Primary Mechanism Finding ids use **`[PM ID]-F[n]`** (example: `PM9-F1`).

Interpretive constraints use **`[PM ID]-IC[n]`** and **do not** consume F sequence
numbers (example: `PM9-IC1`).

Connected / Supportive Evidence does not receive Finding ids.

While a PM is being established (pre-freeze), F numbers follow **canonical Finding
presentation order** on the page. Once a PM is formally frozen and ids have external
dependencies, **do not renumber** stable ids because presentation order, inserts, or
UI layout changed.

Finding ids are canonical for structured data, anchors, cross-references, and audit
machinery. Reader-facing titles derive the short local identifier from the canonical
ID and combine it with `finding_label`: **SF1 — Descriptive finding title**, never
**PM1-F1 — Descriptive finding title**. Do not store a second identifier or renumber
canonical IDs. Stage 2A authors a concise, precise descriptive label aligned with
the assessed proposition; labels do not imply broader dietary or clinical effects.
Map every headline Finding to an explicit Section 4 explanation. Reuse the derived
SF identifier and exact descriptive label in its paragraph heading, with reciprocal
links. Apply the shared combined Section 4 heading and dynamic Finding count;
do not create one headline Finding per study or silently change scientific scope.
Follow the [shared PM presentation rule](primary-mechanism-schema.md#pm-scientific-findings--canonical-41-legacy-51)
for dynamic section counts, intervention links, SEC and Evidence & Audit identity.

Legacy `SF-PM8-n` ids on the former PM8 page (now PM9) were migrated to `PM9-Fn` / `PM9-IC1` when the production
contract was established.

**Depth is proportional.** Individual Study Assessment fields are complete when
present, but full extraction is required only where needed to adjudicate the
proposition — not by default on every study. Pilot 1 depth was appropriate to
architecture stress-testing; it is not the default depth for every PM.

Phase 3 phenome review (`system/phenome-relationship-review-methodology.md`)
validates Biology → Phenome Confidence for candidate relationships. It does **not**
authorise open-ended PM-wide Scientific Finding discovery.

Biology → Phenome Relationship Strength describes the proposed functional
dependency. It is conceptually separate from Synthesised Evidence Confidence,
which describes how strongly the assessed evidence supports a Scientific
Finding. Neither value may be inferred from the other.

**Biochemical requirement is not dietary modulation.** Establishing that a
substrate, ion, cofactor, enzyme or metabolite is required for a reaction does
not establish that ordinary dietary intake controls that reaction, that greater
intake increases flux, or that an intervention changes a phenome or clinical
outcome. Preserve those as separate propositions and claim levels. See
§ **Claim thresholds**: biochemical necessity, dietary provision, demonstrated
modulation and functional or clinical benefit remain distinct.

## Dietary input traceability (PM evidence)

**Input page link.** Every lever Input that has a page in this system links to
that page from the Input line inside the six-atom dietary disclosure. The compact
heading above the disclosure stays plain text. Do not link “Glutathione —
Biochemical requirement”; link `Input = Glutathione`. This applies to PM, SM,
and KC levers. A preparation, practice, pattern, or class with no page stays
unlinked. Do not match a longer phrase to a shorter page. The resolver and
presentation rule live in `system/dietary-input-traceability-contract.md`
(**Input page link**).

When adjudication establishes a **dietary-relevant** biological requirement, follow
the **2B — Dietary Input Traceability & Visibility Contract**
(`system/dietary-input-traceability-contract.md`) — authoritative definition of the
six-atom dietary evidence relationship, reappearance rules, presentation contract, workflow, and
optional `dietary_input_traceability` front matter.

Stage 2A public Findings and connection copy follow
`system/primary-mechanism-schema.md` § **Stage 2A — audience and public voice**
(interested public; nutritionists as the most specialised intended readers).
Apply the same schema's **Technical language policy** for first-use scientific
abbreviations in each independently readable Finding or disclosure context.
Stage 2A also establishes **published PM connections** in §5.2 / §5.3 (or
§6.2 / §6.3): each link needs an evidence-supported relationship explanation
before Stage 2B classifies diet. Identify supported upstream PM dependencies
so Stage 2B can display always-visible indicators beside qualifying
dietary-entry labels. See § **Stage 2A — connected-mechanism presentation**.
Record in the Stage 2A report where a detailed supply or transport assessment
lives; do not write ownership into public copy, and do not suppress a
downstream dependency.

Published §5.2 / §5.3 connection explanations are not a Type D KC mapping.
Stage 2B tests shared-constraint applicability separately
(`system/dietary-input-traceability-contract.md` § **Type D — shared-constraint
applicability**).

When a Finding supports a PM-owned **System Optimisation Practice** or **Lifestyle
Priority**, store the same six atoms in `system_optimisation_practices` or
`lifestyle_priorities`. The collection determines §3.2 or §3.3 placement. These
relationships remain in the PM scientific-evidence layer and are not provisional
Dietary Levers candidates.

Not every Finding is dietary-relevant (e.g. interpretive constraints without dietary
biology). Do not create artificial dietary-input records for those Findings.

Record downstream representation gaps in `system/mechanism-change-control-queue.md`.

## Source of truth

| Layer | Location | Status |
|-------|----------|--------|
| Findings | `scientific_findings` in PM front matter | **durable source** |
| §4.1 Summary | `scientific_findings_intro` in PM front matter | **durable source** — concise synthesis of the most relevant adjudicated findings and overall evidence picture, with studied context and limitations; not a repeat of §4 mechanism biology |
| Dietary-input atoms | `dietary_input_traceability` in PM front matter (when populated) | **durable source** — see dietary-input-traceability-contract.md |
| System Optimisation Practice atoms | `system_optimisation_practices` in PM front matter (when populated) | **durable PM scientific-evidence source** |
| Lifestyle Priority atoms | `lifestyle_priorities` in PM front matter (when populated) | **durable PM scientific-evidence source** |
| Finding → phenome links | `scientific_findings: [id]` on each `phenome_relationships` entry | **durable source** |
| PM Mechanistic Basis Finding subsection | generated by `npm run findings:sync` at canonical §4.1 or legacy §5.1 | generated |
| PM Phenome Connections body | generated by `npm run phenome:sync` at §7 | generated |
| FM §4.4 roll-up | generated by `scripts/populate-fm-evidence-highlights.mjs` from PM front matter | generated |
| References | `static/bibtex/BRAIN-diet.bib` | **durable source** |

Never hand-edit a generated section. `npm run findings:check` fails if either
the Mechanistic Basis Finding subsection or the Phenome Connections body on a
Findings-owned PM has drifted from front matter.

For pages using the canonical PM order, the same generated layers are §4.1
Scientific Findings and §7 Phenome Connections. Untouched pages may retain the
legacy §5.1 / §3 positions; shared layout detection controls placement.

Phenome freshness for Findings-owned pages is enforced by `npm run
findings:check`. To repair a stale page, regenerate only the target file (`npm
run phenome:sync -- --file <path> --pm-only`) and inspect the target-scoped
change. Relationship Findings render fully only in their declared
`primary_phenome`; other relationships reference the same Finding id and must
not inline a duplicate evidence body.

## Cardinality

```
Scientific Finding → 0..n phenome relationships
```

A Finding is authored **once**. Relationships reference it by id; they never
inline a copy. A Finding that informs no relationship is valid when the proposition does not map
to any phenome attached to that PM.

`Scientific Finding → 0..n Nutritional Targets` is accepted conceptually but is
**not implemented**.

## Structure

```yaml
scientific_findings:
  - id: PM9-F1                        # PMn-Fm headline; PMn-ICk interpretive — unique on page
    finding_label: >-                 # required — human-readable title (Level 1–2 default)
    presentation: mechanistic-basis   # mechanistic-basis | phenome-relationship | interpretive-constraint
    primary_phenome: Emotional Regulation # required only for phenome-relationship presentation
    fm_rollup: true                   # explicit FM §4.4 selection; omit/false means no roll-up
    therapeutic_area_ids:            # optional — condition populations directly represented by the Finding
      - TA001                        # canonical IDs from phenome-registry.json; not inferred from Phenome relevance
    finding_summary: >-               # recommended — plain-language opening (self-contained)
    finding_interpretation: >-        # optional — practitioner “What this means” / boundary
    finding_statement: >-             # required — the assessable proposition (Level 3 audit)
    finding_discriminator: >-         # conditional — only when siblings could be confused
    synthesised_evidence_confidence: not-yet-scored   # only authorised value
    synthesis: >-                     # required — what the evidence supports together
    synthesis_limitations: >-         # required — how far it can be taken together
    evidence_considered:              # required, ≥1
      - label: Martin & Rimvall (1993)
        citation_key: martin_regulation_1993
        href: /docs/papers/BRAIN-Diet-References#martin_regulation_1993
        data_level: Mechanistic       # see phenome-relationship-schema.md
        exposure_context: isolated-substance # optional, extensible; preserve what was tested
        evidence_source: bounded-external-search   # or repository-inherited
        directional_finding: >-       # required — collapsed line, direction preserved
        assessment:                   # Individual Study Assessment
          study: >-
          population: >-              # mandatory; therapeutic-area framework
          result: >-                  # direction must be preserved
          effect_magnitude: >-        # say so plainly when none is interpretable
          evidence_summary: >-
          limitations: >-
    connected_supportive_evidence:    # optional
      - label: …
        why_relevant: >-
        why_excluded: >-              # why it is not in the primary synthesis
    evidence_dependency:              # optional; free prose, one note per dependency
      - >-
```

## Rules enforced by `validateScientificFindings`

- Finding ids are unique and match `PMn-Fm` (headline) or `PMn-ICk` (interpretive constraint).
- `therapeutic_area_ids`, when present, is a list of canonical Therapeutic Area IDs.
  Tag only a condition population directly assessed or synthesised by the Finding;
  do not infer tags from a Phenome's broader Therapeutic Area relevance.
- Headline mechanistic Findings use `presentation: mechanistic-basis`; interpretive
  constraints use `presentation: interpretive-constraint` (not headline Findings; render
  at the point of inference they constrain — typically the referencing Phenome Connection
  in §5, not automatically in §4.1).
- `finding_statement`, `synthesis` and `synthesis_limitations` are present.
- `synthesised_evidence_confidence` is `not-yet-scored`. There is no authorised
  mapping from legacy confidence values, and the confidence indicator must
  receive a determined state rather than infer one.
- Every study has a `directional_finding` and a valid `evidence_source`.
- `data_level` comes from the shared reference vocabulary.
- `exposure_context`, when present, is a non-empty description of what was tested
  (`whole-food`, `dietary`, `isolated-substance`, `standardised-extract`,
  `supplemental-formulation`, `combination-formulation`, or a more precise value).
  It belongs to the evidence relationship, not the intrinsic entity, and the
  vocabulary remains extensible rather than a closed enum.
- An Individual Study Assessment, when present, is complete.
- Connected / Supportive Evidence states both why relevant and why excluded.
- Every `scientific_findings` id on a relationship resolves to a declared Finding.
- A study may be primary Evidence Considered in more than one Finding when it
  bears on more than one proposition; reuse must be declared under Evidence
  Dependency so it cannot read as independent replication.
- FM evidence selection is explicit: only non-interpretive Findings carrying
  `fm_rollup: true` may enter FM §4.4. There is no declaration-order or
  “first two Findings” fallback.
`confidence`, `evidence_confidence`, `evidence_level` and `relationship_type` on
## PM numbered references (presentation)

On first mention within a PM section, Scientific Finding evidence renders as
**`Author et al. (year) [n]`**; two-author studies render as
**`Author and Author (year) [n]`**. The numbered square bracket links to the
canonical `## 7. References` entry (anchor `pm-ref-n`). Later mentions in the same
section may use linked `[n]` alone. Author text, year, number and link are all derived
from the same front-matter reference record, never maintained as parallel display data.
Use `{{cite:citation_key,citation_key}}` in `phenome_relationships[].rationale`; sync
resolves keys to canonical author–year + numbered links. The same `citation_key`
always maps to the same number on a given PM page. Validation fails on missing,
duplicate, stale, misnumbered or unlinked body citations and reference anchors.

phenome relationships are **legacy** values on a different scale from
Synthesised Evidence Confidence. Findings do not read, rescore or replace them.
Where adjudication shows a legacy value is no longer adequate, record it in
`system/mechanism-change-control-queue.md` rather than silently changing it.

### Synthesised Evidence Confidence display

The stored finding value remains `not-yet-scored` until evidence governance records an adjudicated score. Do not write a display label or a guessed total back onto a finding. Raw SEC, an adjusted confidence decision, and the reader-facing label stay distinct.

When governance scores a defined proposition, the raw total is **SEC = D + B + P + R**. Each factor is an integer 0–2:

- **D — Directness:** relevance to the exact claim, intervention and endpoint.
- **B — Bias protection:** protection against systematic error.
- **P — Precision:** precision and uncertainty of the evidence.
- **R — Replication:** independent replication and consistency.

The raw total is 0–8. The display component does not calculate these factors. A single unreplicated study cannot receive full replication credit. A raw zero, a missing assessment, or any value that is not an integer 1–8 is **Not scored**. It is not shown as 1.

An adjudicated cap or downgrade is the displayed decision. The raw total does not override it.

Reader-facing labels for a valid display score:

| Score | Label | Colour family |
|---|---|---|
| 1 | Extremely Low | Red |
| 2 | Very Low | Red |
| 3 | Low | Yellow |
| 4 | Low–Moderate | Yellow |
| 5 | Moderate | Orange |
| 6 | Moderate–High | Orange |
| 7 | High | Green |
| 8 | Very High | Green |

The indicator is four grouped blocks, two increments each. Scores 1–2 use the existing red token, 3–4 yellow, 5–6 orange, and 7–8 green. Inactive increments stay neutral. The readout is the score out of 8 and the label, for example `6/8 · Moderate–High`.

This is confidence in a defined evidence proposition. It is not the quality of one study alone, a count of studies, the probability that the finding is true, the magnitude of benefit, clinical effectiveness, or scientific admission. Do not infer a Dietary Requirement, SOP, lifestyle lever, or phenome admission from the displayed score.

Legacy four-level words (`very-low`, `low`, `moderate`, `high`) and phenome confidence values stay on their own scale. They are not converted into SEC numbers. No new scientific admission categories are created.

### Scientific Findings — Summary authoring rule

Summarise the most relevant adjudicated findings and the overall evidence picture in a short reader-facing paragraph. State what the strongest evidence establishes, identify important convergence or differences in results, and preserve the studied context and principal inference boundary. Distinguish measured endpoints from inferred mechanisms. Reuse the existing Finding records and target-page numbered bibliography references. Do not substitute a mechanism walkthrough, nutrient inventory, list of section contents, or generic statement that “the findings below” support the biology. §4 explains how the process works; this Summary explains what its evidence shows. Where evidence is limited to biochemical or preclinical work, say so without manufacturing a human result. Summarise rather than enumerate every study; adapt length to the available evidence. Necessary biological wording may recur for clarity: the test is added evidence interpretation, not artificial variation. Preserve the stable `scientific_findings_intro` source field.


## Sixth atomic field — Dietary input (Stage 2A / Stage 2B)

The PM dietary-context contract is **Input | Input type | Biological role | Evidence source | Limitation | Dietary input**. Store the sixth field on the authoritative `dietary_input_traceability` atom as `dietary_input: true`, `false`, or `null`; render these as **Yes**, **No**, or **Unset — clarification required**. Never copy the decision into a separately editable food registry or lever overlay. `dietary_input_note` and `dietary_input_flags` are review metadata, not additional atomic fields. Missing legacy values remain unset until reviewed.

Stage 2A makes the existing accepted supply decision explicit; Stage 2B projects that same atom without reassessing evidence. Preserve findings, citations, limitations, biological role, relationship classification, ownership and upstream/KC applicability.

- §1.1.1 / §3.1.1 Direct/Derived Dietary Requirements normally receive Yes because section admission establishes dietary applicability. Explicit contradictions must be flagged (`section-supply-contradiction`), leaving the value unset pending resolution rather than silently overriding either record.
- §1.1.2 / §3.1.2 Cofactors and Substrates require individual review of the accepted biological role, supply route and limitation. Intracellular participation alone establishes neither Yes nor No.
- §1.1.3 / §3.1.3 Key Constraints/upstream resource inputs distinguish dietary constituents from the pool or constraint itself. A constituent may receive Yes; a pool reference receives No when no dietary supply relationship is admitted for the pool itself. Constituent decisions remain on their PM atoms, never inherited from KC applicability.
- Ambiguous cases receive `dietary_input: null`, a specific `dietary_input_note` and a clarification flag. Do not default to No.

No means **no dietary supply relationship is admitted for this entry in this PM**. It does not mean the substance is absent from food or biologically unnecessary. Lack of demonstrated benefit from extra intake, dose responsiveness or a universal requirement is not alone a reason to assign No. Dietary input and PM ownership/upstream/accounting designation are independent fields.

```yaml
- atom_id: PM-example-DIT-1
  input: Vitamin B6
  input_type: cofactor precursor
  biological_role: Accepted precursor provision for intracellular PLP
  evidence_source: # retain accepted finding and citation references
    finding_ids: [PM-example-F1]
    citation_keys: [accepted_reference_key]
  evidence_limitation: Retain the accepted limitation verbatim
  dietary_input: true
  dietary_input_note: Accepted dietary precursor route; no conversion yield inferred
```

Generate PM-input substance–food lists only for `dietary_input === true`. Keep No and unset entries visible as biological context; suppress their food lists without removing canonical food composition records. The same substance may have Yes and No entries in different PMs. Generated tables expose the sixth field and source note; retain unresolved rows and gaps. Missing optional food quantities do not suppress an admitted qualitative food relationship. SOP and lifestyle records also carry the same sixth field where evidence-qualified, but their category remains SOP/lifestyle; a Yes value never migrates them into Dietary Requirements.


## Dietary pathway discovery and activation — 26 October 2026

Trace food → canonical dietary input → endogenous/microbial conversion → active biological substance → receiving PM operation. Reuse ordered `conversion_pathway` on admitted assessments; do not flatten B6 vitamer alternatives. Canonical substance `formation_pathways` may document separately evidenced biochemical production, with stable ID, exact from/to identities, relationship, status, process, dependencies, evidence and limitations. Unresolved formation records are review context, never traversable active edges.

Classify and verify each edge independently. Type A requires established PM-specific capacity plus supported dietary supply; it does not require extra-intake or clinical benefit. Type B requires supported delivery and engagement of the receiving operation. A connected graph, a metabolite concentration, an enzyme role or food composition alone cannot supply a missing admission link. Direct/Derived is relative to the receiving operation, not the number of graph edges. Preserve historical admissions and mark missing machine-readable chains explicitly instead of deleting records.

Use `scripts/generate-dietary-pathways.mjs` and the shared `buildDietaryPathwayIndex` for the complete 64-PM inventory, qualified production pathways and gaps. Shared pages project this same index; never copy food lists or inherit downstream admissions. Substance routes use canonical IDs and structured verified/provisional food relationships. Recipes may expose ingredient pathway context but must not imply direct metabolite content or efficacy. KC projections require independently admitted constituent identities; graph reach is not KC membership.

Butyrate pilot ceiling: RS utilisation/cross-feeding is context-dependent; pectin evidence supports SCFA-mixture context, without transferring purified-substrate responses to apples. FOS/GOS remains under review. PM1-H1 remains Unestablished unless its complete joined epithelial pathway passes a separate adjudication. Keep Moreau temporal findings, Peng cellular evidence and human paracellular/transcellular distinctions. Do not turn food → starch → butyrate into an admitted tight-junction intervention automatically.

Future Stage 2A/2B runs must preserve six atoms, evidence provenance, conversion dependencies and immutable SEC history. Report empty admitted sections separately from identity gaps, food gaps, conversion gaps and unresolved PM engagement. Run pathway mutation/preservation tests and real substance/PM/food/recipe browser checks before claiming implementation complete.

## SEC assessment completeness — 2 November 2026

Stage 2A must follow [Assessment completeness](sec-assessments/README.md#assessment-completeness--approved-extension-2-november-2026). Classify scientific propositions separately from appraisal tasks. Track pending or unassessable SEC dimensions with Assessment gaps in the existing versioned assessment; never manufacture a scientific Evidence Gap or numerical zero from missing appraisal. Report eligible/completed/pending/unassessable/missing-status Findings, dimension coverage, and scientific Evidence Gap linkage/review status separately. Run `scripts/check-sec-completeness.mjs --pm <id> --check` and the `--require-appraised` gate before declaring the run scientifically appraised. Preserve old SEC versions and Evidence Gaps; resolution of an Assessment gap triggers dimension reassessment, not automatic closure of a scientific Evidence Gap. Public labels are Evidence Gap, Assessment gap, Pending appraisal and Evidence Un-assessable; do not introduce gap acronyms.

For scientific approval, supply `--base <reviewed-git-ref>` with `--require-appraised` to compare prior canonical Evidence Gap IDs; the approval gate rejects omission of this preservation baseline. Structural report mode remains available without a baseline.

## Presentation correction — 2 November 2026

Do not generate or render dated “Stage 2A/2B evidence and traceability review” execution panels in canonical pages, including Evidence & Audit. Historical execution reports remain in their source/archive records; the legacy `Stage2Review` wrapper is non-rendering compatibility only. Use the governed Finding, Principle, assessment, correction and gap interfaces for scientific records. This removes no scientific evidence and does not remove the public Framework Review & Corrections register link.

### Stage 2A handoff — intervention presentation (2 November 2026)

Supply a precisely bounded practice/comparison title, demonstrated endpoint, evidence type, population, exposure, original citations and separate limitations for each proposed SOP or Lifestyle Lever. Follow **Intervention presentation: practice before appraisal** in `dietary-input-traceability-contract.md` at Stage 2B rendering. Do not substitute circulating concentration for dietary appearance flux, or conceal essential boundaries inside a disclosure. This presentation change neither requires a new Finding per intervention nor transfers a linked Finding’s SEC to the intervention.

### Recipe pathway presentation boundary — 2 November 2026

Stage 2A evidence discovery may reuse ingredient pathway records, but must not generate a public recipe-level pathway panel from food tags. Stage 2B follows the recipe boundary in `dietary-input-traceability-contract.md`; preserve ontology evidence without implying recipe-specific engagement or adding unapproved recipe sections.

## Mandatory author approval for presentation changes

Follow [presentation-change-control.md](presentation-change-control.md). Scientific data integration does not authorise public presentation. New substantive blocks require a proposal, representative rendered example, page-type/count scope, updated contract and explicit prior author approval. Run `npm run presentation:check`; never regenerate the baseline or invent an approval to bypass a failure. Both Dietary pathways technical panels are withdrawn across all page types; preserve their data without public projection. This rule supersedes earlier instructions permitting automatic pathway displays.

## SOP/Lifestyle Mechanism-of-Action integrity — 2 November 2026

Follow [the six-atom SOP/Lifestyle contract](sop-lifestyle-six-atom-presentation.md). Intervention, full MoA, Measured Effect, PM Relevance and Evidence Limitations must remain separate. Unresolved MoA produces no collapsed Mechanism line. Evidence-status text cannot substitute for a process, and a measured effect does not establish mediation. Preserve existing admission, dominance, SEC and Dietary Confidence rules. This is an authorised governance correction; canonical presentation rollout requires separate explicit approval.

## Two-pass SOP/Lifestyle execution — owner instruction 2 November 2026

**Pass 1 takes priority across all 64 PMs.** Review mission relevance, original evidence, measured effects, identifiable MoA, independently typed limitations, PM-specific admission and ontology links. Implement only eligible interventions through the approved six-atom presentation, including legitimate dominance placement. An unresolved MoA does not automatically disqualify or admit an intervention. Contextual, mechanistic and unverified candidates must not be automatically admitted. Record intervention-specific SEC status as **Not yet assessed** unless an existing valid assessment covers the exact intervention–outcome proposition. Preserve any valid existing intervention assessment. Do not assign new intervention SEC scores or inherit Finding scores. Extract paper-relevant examples incrementally.

**Pass 2 follows Pass 1.** Appraise admitted SOPs and Lifestyle Levers using the existing D/B/P/R rubric, exact intervention–outcome proposition and retained provenance. Use existing Assessment Gap tracking for incomplete appraisal. Present scoring in Section 4, not in the six atoms. Flag material appraisal problems for admission adjudication; do not silently rewrite admissions. Preserve scientific Findings, dietary admissions and immutable SEC history.

Track scientific eligibility, implementation/validation and SEC appraisal independently. Pass 1 completion is not scoring completion. No new public presentation component or deployment is authorised by this sequencing instruction.

## Dietary-first editorial placement — approved 2 November 2026

This owner-approved rule supersedes requirements above that make routine dietary-first presentation depend on demonstrated comparative intervention dominance.

- Where a PM has admitted Dietary Levers, present that group first by editorial default because the framework is diet-focused. Placement is not a claim that diet is biologically stronger, more effective or more important than SOPs or Lifestyle Levers.
- Retain SOPs and Lifestyle Levers in their standard sections unless an explicitly justified presentation exception is approved. Do not withdraw previously approved exceptions automatically.
- Keep scientific Intervention Dominance separate. Where comparative evidence does not establish a principal route, retain or record “No principal intervention route established”. Do not assign Diet-Dominant merely to achieve dietary-first placement or populate scientific `selected_groups` from editorial preference.
- Admission remains evidence-governed. Dietary-first placement neither admits a candidate nor promotes biochemical-only participants. Specificity alone does not establish dominance; a defined SOP can also be specific. Empty dietary groups must not be promoted or filled artificially.
- Routine Pass 1 presentation and paper extraction need not wait for comparative dominance adjudication. Record genuine scientific uncertainties separately and continue. Existing scores, admissions, scientific qualification labels and immutable history remain unchanged.
- Future generator implementation must represent editorial placement separately from scientific route selection. This instruction approval does not itself confirm that the current generator implements the separation; validate before reporting rollout completion.


### Intervention-specific SEC ownership — PM3 integration, 3 November 2026

The owner-requested PM3 appraisal is a bounded exception to the two-pass rollout priority. An SOP or Lifestyle Lever assessment uses the existing D/B/P/R rubric, caps and immutable SEC registry, with `interventionId` instead of `findingId`. These ownership fields are mutually exclusive. Never reinterpret an interpretive-constraint identifier as an intervention or inherit a linked Finding's score.

A canonical intervention atom pins `sec_assessment_ref: {id, version, sha256}` and the exact `sec_assessed_proposition`. Resolve against its `atom_id`, PM identity, proposition and content pin. Assessment gaps use the same intervention owner and existing dimension-level tracking. Missing values remain null, pending dimensions require actionable Assessment gaps, and pending appraisal blocks scientific approval. Provisional appraisal is not human scientific acceptance or automatic intervention re-admission.

Existing Finding assessments and all historical snapshots remain immutable. This extension stores intervention assessments and updates existing status text only; it does not authorise a new public panel. Numerical assessment presentation remains governed by Section 4 and its separately approved presentation contract. Keep intervention coverage separate from Finding coverage.

### BRS2 PM1 presentation correction — 3 November 2026

Use the existing `brs-fm-hub-*` disclosure markup for SOP category groups, matching §1.1; do not wrap interventions in generic MDX `<details>` cards with theme-coloured backgrounds. Individual rows retain `brs-dietary-lever-trigger` styling. A mechanism summary may describe established nutrient provision without asserting unmeasured intracellular conversion or mediation. Preserve those qualifications in Atom 3. The steaming example remains unresolved: do not invent a leaching mechanism from folate-retention measurements alone.

## PM1 controlled reference completion — 3 November 2026

Owner instruction: resolve PM1 issues starting with F3, complete SEC appraisal, apply PM8 tabs and approved six-atom presentation; no commit or push. Scope is BRS1-FM1-PM1, not framework-wide refactoring or certification of a finished Gold Standard.

Separate established reaction identity from an empirical physiological-supply proposition. In PM1, SP1 retains PAH reaction identity; F3 retains human conversion/circulating-supply evidence and requires its own assessment. A Principle does not exempt an overlapping physiological Finding from SEC. Preserve stable IDs and historical assessments. Document exact source access; an abstract or a review describing primary studies is not full-text primary appraisal. Use existing Assessment gap/unassessable rules when retrieval cannot resolve required dimensions; do not invent values to complete coverage.


## PM1 Section 4 assessment-family grouping — approved 4 November 2026

Author-approved PM1-only pilot: keep the Section 4 summary visible; group Scientific Findings first, SOP assessments second, and Lifestyle Lever assessments only when present. Each family starts collapsed and uses existing `brs-fm-hub` dropdown CSS and keyboard behaviour. Individual Findings/assessments retain their own disclosures; stable deep links must open all enclosing groups. Scores, assessment ownership, six atoms and admissions are unchanged. Do not display empty Lifestyle assessment groups.

Stage 2A preserves separate scientific and intervention propositions; grouping never implies inherited scores. Stage 2B renders the approved family order and preserves the `section4-findings:end` generated boundary so regeneration cannot discard following SOP assessments. `section4_assessment_groups: true` is enabled only on PM1 in this pilot; do not activate other PMs without rollout authorisation. This presentation approval is not scientific reassessment.

### Reference presentation correction — 4 November 2026
Stage 2A source-access tracking is not an additional PM reader-facing section. Follow `system/brs-citation-reference-standard.md`: no PM-local source audit annex or historical reference narrative. Preserve scientific evidence and SEC history; publish concise numbered references linked to verified master bibliography entries. Do not copy retrieval logs into the References section or another public tab.


### Scientific Lesson placement — owner clarification, 4 November 2026
Scientific Lessons remain permitted. Use the approved GAD lesson disclosure (`scientific-lesson brs-fm-hub-item`, book icon, kicker and concise title) beneath the relevant Scientific Finding within Section 4. Preserve the authored `scientific-lesson:<Finding ID>:start/end` island during regeneration. Do not append a standalone Scientific Lesson after References. Lessons explain existing evidence boundaries; they are not new Findings or independently scored claims. PM1's circulating-versus-brain-delivery lesson is placed beneath F1, with links to the other relevant Findings; avoid stale hard-coded display numbers. This change authorises PM1 placement, not a wider lesson rollout.


**PM1 placement correction — 4 November 2026:** The owner subsequently requested its lesson above and separate from the Scientific Findings. Place the existing GAD-styled lesson disclosure before §4.1, outside the Findings parent and generated Findings block. Preserve its stable anchor and supporting Finding links. This supersedes the immediately preceding PM1-beneath-F1 placement instruction; it does not move other PM lessons.


### Authoritative Scientific Lesson placement — 4 November 2026

This supersedes earlier lesson-placement amendments above. Place each existing Scientific Lesson **at the end of the Section 4 Summary**, immediately after its summary prose and before mechanistic-detail or Scientific Findings disclosures. Lessons are separate sibling dropdowns, never children of the Scientific Findings parent or an individual Finding, and never appended after References. Reuse the GAD lesson CSS, book icon, concise title and initially collapsed behaviour. Preserve lesson identity, content and supporting Finding links; do not assign a new score or create a Finding. Keep the lesson outside the generated §4.1 block so regeneration cannot move or erase it. This instruction applies to existing lessons; do not invent lessons to populate every PM. Checked canonical PMs: PM1 and GAD/PM9 contain actual lesson disclosures; other authored-lesson markers alone are not lessons.


### Food occurrence versus ranking — presentation clarification, 9 November 2026

Author-approved PM visibility correction: inability to rank a documented qualitative food source is not absence of a dietary relationship or grounds to withdraw its admission. Stage 2A preserves source-specific chemical form, preparation, occurrence evidence and delivery limitations. Stage 2B projects the separate ranked and documented-unranked layers under `system/input-substance-food-mapping.md`; quantitative eligibility and scientific admission remain distinct. No new evidence classification, conversion yield or efficacy inference is authorised.


### Shared-documentation identity extension — 9 November 2026
Use the registered child identity/shared-page convention in system/substance-page-schema.md for approved studied preparations, defined mixtures and exact strains. Documentation parentage is independent of taxonomy and mixture composition. Registration does not admit a PM relationship or activate food/network projection; preserve network_activation=held and existing PM projection holds until source-specific formulation and publication eligibility are separately approved. No parent/child inheritance of food quantities, PM admissions, effects or SEC.


Identity-resolution clarification, 9 November 2026: network_activation=held does not block an explicitly authored PM substance_id from resolving to its registered identity. It continues to block automated alias activation and food-source projection. Preserve canonical_identity.projection_status and independent scientific/publication holds. Approved identity-only fingerprint transitions are recorded separately in system/dietary-input-identity-reconciliations.json; the immutable historical baseline is not regenerated, and any other scientific change invalidates the transition.


### Typed non-substance PM source identities — approved 9 November 2026

An existing PM atom may carry source_identity with kind (source-class, functional-substrate-class, dietary-matrix or preparation-characteristic), pm_atom_id (full PM ID::atom ID), status=resolved and substance_applicability=not-applicable. This resolves its representation, not scientific efficacy, admission, food eligibility or conversion completion. Do not create a substance ID. Retain original input_type, evidence, limitations and projection holds.

A conversion assessment may use source_atom_id instead of canonical_substance_id. Validation must receive the referenced canonical record in sourceAtoms, verify the same candidate PM atom and input label, and allow that typed identity only as the first conversion origin. Subsequent steps and the target still require canonical substance identities. Evidence, dependencies, admission and pathway-continuity gates remain unchanged; a typed functional fibre source does not complete the butyrate pathway. Report non-substance connections separately from substance/preparation/strain pairs. No conversion efficiency or downstream quantity is inferred.


### Approved measured-but-unrankable sources — 9 November 2026
Owner approval: CODEX EXEC — Measured-but-Unrankable Food Presentation. Reuse Documented, unranked sources for 5-MTHF, ellagic acid, inulin and resistant starch. Show original point/range, unit, denominator, preparation, citation and exclusion reason. Separate calculated-from-measurements, measured non-comparable and qualitative occurrence labels. Keep independent studies separate and retain calculation/variability/source qualifications. Verified provisional source-context mappings remain explicitly qualified, not silently upgraded. Preserve all target/source publication and protocol holds. Never recover sources excluded solely by RSP threshold or top-ten cap; rankings remain unchanged. No inferred conversions, range midpoints or downstream quantities. See review/dietary-connectivity-2026-11-09/measured-unranked/REPORT.md.


## Canonical scientific projections — approved 10 November 2026

Apply [Canonical scientific truth and presentation consistency](canonical-scientific-projections.md), including its five scientific, automated, release and publication checkpoints. Current mission comes from PM frontmatter; explanatory prose must not strengthen the canonical science. Preserve authoritative admissions, limitations and SEC history. Report conflicts with provenance instead of selecting the newest text.
