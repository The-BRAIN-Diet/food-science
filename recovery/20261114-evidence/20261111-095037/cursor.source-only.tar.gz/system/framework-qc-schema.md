# Framework QC (Phase 0 / 0.5)

Internal quality-control inventory plus a **derived** public Review & Corrections view. Do **not** add QC fields to content-page front matter. Do **not** recreate or duplicate these registers.

## Registers

| File | Role |
|------|------|
| `system/framework-qc/framework-issues-register.json` | Hand-maintained framework issues and PM Review & Corrections decisions (source of truth). |
| `system/framework-qc/pm-open-issues.json` | Hand-maintained **current** unresolved questions for one PM. Not a copy of the framework register. |
| `system/framework-qc/page-review-state.json` | Hand-maintained review fields for pages that are not still `unreviewed`. |
| `scripts/out/framework-qc/page-review-register.json` | **Generated** inventory of every `docs/` page. Do not edit by hand. |
| `scripts/out/framework-qc/page-review-report.md` | **Generated** counts report. |
| `scripts/out/framework-qc/review-queue.html` | **Generated** internal Review Queue view. Derived from the two registers plus scan metadata. Not a third data register. |
| `src/data/framework-qc-public.generated.json` | **Generated** public-safe dataset for the Docusaurus site. Derived from the same two registers. Not a third data register. |

Regenerate:

```bash
npm run qc:generate
```

## Page Review Register (generated row)

| Field | Notes |
|-------|--------|
| `page_id` | Front-matter `id`, `pm_id`, `fm_id`, `kc_id`, `sm_id`, or path-derived slug |
| `path` | Repo-relative `docs/…` path (internal only) |
| `title` | Front-matter `title`, else file stem |
| `page_type` | `Food` `Substance` `Recipe` `BRS` `FM` `PM` `KC` `SM` `Dependency` `Index` `Phenome` `Framework/methodology` `Other` |
| `letter` | First A–Z of title (else `_`) |
| `review_status` | See below |
| `last_checked` | ISO date or `null` |
| `checked_by` | Internal reviewer identity or `null` (never public) |
| `public_reviewer` | Public reviewer name or role |
| `review_scope` | Public description of what was checked |
| `accepted_limitations` | Public limitation strings |
| `linked_framework_issue_ids` | IDs of issues that **specifically** target this page. Framework-wide issues are **not** copied onto every row. |

Default when no state exists: `review_status: unreviewed`, empty linked IDs, null dates.

Allowed `review_status`: `unreviewed` | `issues_logged` | `source_checked` | `expert_reviewed` | `recheck_required`.

`SM` is Specific Mechanism pages (`docs/biological-targets/**/sm/**`). `Dependency` is BRS dependency pages (`docs/biological-targets/dependencies/`). `Index` is collection/folder `index.md` pages that are not already a more specific type (for example Dietary Foundations index remains `Framework/methodology`). Do not invent types for remaining `Other` pages.

## Framework Issues Register (hand-maintained)

| Field | Notes |
|-------|--------|
| `id` | `FW001`, `FW002`, … |
| `title` | Short internal name |
| `visibility` | `public` or `internal`. Only `public` issues may appear in the public dataset. Missing `visibility` is treated as internal. |
| `public_title` | Optional public title (defaults to `title` when public) |
| `public_findings` | Optional public findings (defaults to `findings` when public) |
| `findings` | Numbered internal findings (array, 1-based in display) |
| `required_action` | Internal: what must happen later (never public) |
| `status` | `open` `deferred` `resolved` |
| `priority` | `high` `medium` `low` (internal) |
| `resolution_summary` | Public resolution text when resolved |
| `resolved_date` | ISO date when resolved |
| `scope` | How the issue attaches (do not explode one systemic issue across hundreds of pages) |
| `affected` | Human-readable pages or scope (internal) |

### Scope

```json
{
  "kind": "page | page_type | letter | brs_hierarchy | framework-wide",
  "page_ids": [],
  "page_paths": [],
  "page_types": [],
  "letters": [],
  "brs_hierarchy": [],
  "subsection": null
}
```

- `page` — named `page_ids` / `page_paths` only.
- `page_type` / `letter` / `brs_hierarchy` — applicable to matching pages in the Review Queue without writing the ID onto every register row.
- `framework-wide` — shown once in the queue’s framework-wide panel.

## Public dataset (generated)

`src/data/framework-qc-public.generated.json` is the public view of the existing registers. It exposes only:

- page ID, public site path, title, page type, letter
- review status, last checked date, public reviewer, review scope
- public issue ID, public title, numbered public findings, issue status
- resolution summary and date when present
- accepted limitations and resolved history

It must not expose internal notes, internal-only issues, private identities, filesystem paths, `required_action`, or implementation metadata.

### Correction decisions (same register file)

Reuse `framework-issues-register.json`. Do not write a second history on the PM page
or in a Stage 2B report.

Required fields on a `record_kind: "correction"` decision:

| Field | Notes |
|-------|--------|
| `scope.page_ids` / `affected_section` | Page and affected section |
| `reviewed_date` | Date reviewed |
| `title` / `public_title` | Issue reviewed |
| `decision` / `public_decision` | Decision |
| `rationale` | Internal rationale (audit only) |
| `public_evidence` | Supporting evidence when applicable (public) |
| `correction_status` | `pending` `accepted` `applied` `superseded` |
| `review_method` | `automated` or `expert` |
| `implementation` | Required before `applied`. Checks must pass. |

`register_surface: "pm-tab"` marks a **PM evidence-audit decision**. Those records
feed the PM **Review & Corrections** tab only. They must **not** appear on
`/docs/dietary-foundations/framework-review-and-corrections` and must not be
linked there from a PM tab.

Evidence `review_status` on `page-review-state.json` is independent of
`correction_status`. Accepted or applied corrections do not complete source or
expert review.

A PM rerun with `rerun_required: true` is incomplete until accepted corrections
and unresolved decisions are recorded. Do not mark `applied` until verification
checks pass.

Public UI:

- Per-page **Review & Corrections** tab (required on every PM; generated from
  linked register records)
- Per-page **Open Issues** tab, rendered only when that PM has current `open` or
  `deferred` rows in `pm-open-issues.json`. Resolved rows leave this tab; their
  decision is a `register_surface: "pm-tab"` correction, not a second write-up.
- Central framework register at `/docs/dietary-foundations/framework-review-and-corrections`
  (**local-only**; framework-surface issues only; not the PM evidence audit trail
  and not the PM Open Issues list)

## PM Open Issues

Current scientific questions and implementation defects for one mechanism. Do not
add these fields to page front matter, and do not copy them into
`framework-issues-register.json` merely because they are unanswered. A PM question
becomes a framework issue only when it is a shared problem affecting multiple pages.

Status reuses the framework vocabulary: `open`, `deferred`, `resolved`. `kind` is
`scientific-question` or `implementation-defect`. Each current row states the
question, what is established, what the uncertainty prevents claiming, and the
evidence or review needed. `finding_ids` and `citation_keys` may link to that
PM’s own Findings and references. `related_framework_issue_ids` may record a
shared cause internally; the tab must not render it or link to the framework register.

`resolved` requires `resolution_correction_id` pointing at a PM Review & Corrections
record for the same `pm_id`. The Open Issues tab then omits that row. Open
questions do not authorise unresolved or rejected relationships as public
requirements. A question that changes an entry’s validity, classification, or
claim is resolved or the entry is withheld before publication. Broader unanswered
questions do not block unrelated supported content.

## Review Queue (generated view)

Built at generate time from the Page Review Register + Framework Issues Register. Default grouping:

1. Page type
2. Alphabetical letter (Foods, Substances, Recipes)
3. Page title
4. Linked **open** page-specific issues

Recipes: meal-category folder before letter. BRS / FM / PM / KC: BRS hierarchy (`BRS5` → `FM2` → `PM4`) instead of letter.

## Working rule

See `.cursor/rules/framework-qc.mdc`. Log outside the active batch; do not fix unless the exception criteria apply.


## Canonical scientific projections — approved 10 November 2026

Apply [Canonical scientific truth and presentation consistency](canonical-scientific-projections.md), including its five scientific, automated, release and publication checkpoints. Current mission comes from PM frontmatter; explanatory prose must not strengthen the canonical science. Preserve authoritative admissions, limitations and SEC history. Report conflicts with provenance instead of selecting the newest text.
